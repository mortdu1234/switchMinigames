# SCOREBOARDS
    scoreboard players set shield ar_options 0

# BLOCKS
    setblock 6 201 -2 obsidian
    data modify block 5 201 -2 front_text.messages[2] set value {"text":"Off","color":"red","bold":true,"click_event":{"action":"run_command","command":"function ar:lobby/shield/enable"}}

# SOUNDS
    execute if score doSounds ar_options matches 1 positioned 5 201 -2 run playsound item.shield.break master @a ~ ~ ~ 1 1 1