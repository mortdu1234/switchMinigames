# TELLRAW
    tellraw @a [{"bold":true,"color":"dark_gray","text":"["},{"bold":false,"color":"white","text":"Akan"},{"bold":true,"color":"gold","text":"RUSH"},{"bold":true,"color":"dark_gray","text":"] "},{"bold":false,"selector":"@s"},{"bold":false,"color":"white","text":" is eleminated!"}]

# GAMEMODE
    gamemode spectator @s

# TELEPORTATION
    tp @s[team=ar_teamRed] 0.5 73.0 65.5 180.0 35.0
    tp @s[team=ar_teamBlue] 0.5 73.0 -64.5 0.0 35.0

# SOUNDS
    execute as @a at @s run playsound entity.lightning_bolt.thunder master @s ~ ~ ~ 1.0 1.0

# TEAM
    team join ar_dead @s

# CHECK END GAME
    execute store result score blue ar_playerCount run team list ar_teamBlue
    execute store result score red ar_playerCount run team list ar_teamRed

    execute if score blue ar_playerCount matches ..0 run function ar:endgame/start
    execute if score red ar_playerCount matches ..0 run function ar:endgame/start