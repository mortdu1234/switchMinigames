# PLACE LOBBY
    execute positioned -6 199 -6 run place template ar:lobby ~ ~ ~ none none 1 1 strict

# OPTIONS
    scoreboard players set doSounds ar_options 0

    execute if score totem ar_options matches 1 run function ar:lobby/totem/enable
    execute if score totem ar_options matches 0 run function ar:lobby/totem/disable

    execute if score shield ar_options matches 1 run function ar:lobby/shield/enable
    execute if score shield ar_options matches 0 run function ar:lobby/shield/disable

    execute if score bows ar_options matches 1 run function ar:lobby/bows/enable
    execute if score bows ar_options matches 0 run function ar:lobby/bows/disable

    execute if score tnt ar_options matches 1 run function ar:lobby/tnt/enable
    execute if score tnt ar_options matches 0 run function ar:lobby/tnt/disable

    execute if score animations ar_options matches 1 run function ar:lobby/animations/enable
    execute if score animations ar_options matches 0 run function ar:lobby/animations/disable

    scoreboard players set doSounds ar_options 1

# UPDATE PLAYERS
    # INVENTORIES
        clear @a
        execute as @a run function ar:ingame/clear_ec

    # EFFECTS
        effect clear @a
        effect give @a minecraft:regeneration 6 255 true
        effect give @a minecraft:saturation infinite 255 true

# ITEMS
    kill @e[tag=ressource]
    kill @e[nbt={Item:{components:{"minecraft:custom_data":{ressource:1b}}}}]

# UPDATE SCOREBOARDS
    scoreboard players set @a ar_death 0
    scoreboard players set @a ar_deathHUD 0

    scoreboard objectives setdisplay sidebar