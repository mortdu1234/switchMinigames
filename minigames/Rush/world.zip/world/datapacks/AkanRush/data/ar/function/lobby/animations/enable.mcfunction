# SCOREBOARDS
    scoreboard players set animations ar_options 1

# BLOCKS
    setblock 6 201 4 crying_obsidian
    data modify block 5 201 4 front_text.messages[2] set value {"text":"On","color":"green","bold":true,"click_event":{"action":"run_command","command":"function ar:lobby/animations/disable"}}

# SOUNDS
    execute if score doSounds ar_options matches 1 positioned 5 201 4 run playsound entity.villager.yes master @a ~ ~ ~ 1 1 1