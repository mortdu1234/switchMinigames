# SCOREBOARDS
    scoreboard players set tnt ar_options 1

# BLOCKS
    setblock 6 201 2 crying_obsidian
    data modify block 5 201 2 front_text.messages[2] set value {"text":"On","color":"green","bold":true,"click_event":{"action":"run_command","command":"function ar:lobby/tnt/disable"}}

# SOUNDS
    execute if score doSounds ar_options matches 1 positioned 5 201 2 run playsound entity.generic.explode master @a ~ ~ ~ 1 1 1