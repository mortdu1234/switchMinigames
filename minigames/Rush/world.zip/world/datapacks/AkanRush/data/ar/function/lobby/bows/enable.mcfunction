# SCOREBOARDS
    scoreboard players set bows ar_options 1

# BLOCKS
    setblock 6 201 0 crying_obsidian
    data modify block 5 201 0 front_text.messages[2] set value {"text":"On","color":"green","bold":true,"click_event":{"action":"run_command","command":"function ar:lobby/bows/disable"}}

# SOUNDS
    execute if score doSounds ar_options matches 1 positioned 5 201 0 run playsound entity.arrow.hit_player master @a ~ ~ ~ 1 1 1