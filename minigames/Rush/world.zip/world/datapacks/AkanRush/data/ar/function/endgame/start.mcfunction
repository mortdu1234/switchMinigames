# UPDATE STATES
    scoreboard players set inGame ar_state 0
    scoreboard players set endGame ar_state 1

# RESET TIMER
    scoreboard players set ticks ar_timer 0
    scoreboard players set seconds ar_timer 0