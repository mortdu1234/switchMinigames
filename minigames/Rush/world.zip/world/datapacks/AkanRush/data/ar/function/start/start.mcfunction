# UPDATE STATES
    scoreboard players set lobby ar_state 0
    scoreboard players set inGame ar_state 1

# UPDATE SCOREBOARDS
    scoreboard players set @a ar_death 0
    scoreboard players set @a ar_deathHUD 0

    scoreboard objectives setdisplay sidebar ar_deathHUD

    # COUNT PLAYERS
        execute store result score blue ar_playerCount run team list ar_teamBlue
        execute store result score red ar_playerCount run team list ar_teamRed

# RESET MAP
    time set 0

    # CLEAR
        kill @e[tag=ar_obsidian]
        kill @e[tag=ar_ec]
        kill @e[tag=ar_bulb]
        kill @e[tag=ar_rod]
        function ar:start/clear_map

    # BLUE SIDE
        execute positioned -8 66 -57 run place template ar:platform ~ ~ ~ none left_right 1 1 strict

    # RED SIDE
        execute positioned -8 66 57 run place template ar:platform ~ ~ ~ none none 1 1 strict

# ITEMS
    kill @e[type=item]
    kill @e[type=arrow]

# SPAWNERS
    kill @e[tag=spawner]
    summon marker 0.5 68.1 -67.5 {Tags:["blue","spawner"]}
    summon marker 0.5 68.1 68.5 {Tags:["red","spawner"]}

# SHOPS
    kill @e[tag=shop]

    # ARMORS
        summon villager -5.5 69 -65.5 {NoGravity:1b,Invulnerable:1b,NoAI:1b,CanPickUpLoot:0b,Tags:["blue","shop","armors"],CustomName:{"bold":true,"color":"gray","text":"Armors & Defenses"},VillagerData:{level:5,profession:"minecraft:armorer",type:"minecraft:snow"},Offers:{Recipes:[{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:iron_ingot",count:4,components:{"minecraft:item_name":{"bold":true,"color":"gray","italic":false,"text":"Iron"}}},sell:{id:"minecraft:chainmail_chestplate",count:1,components:{"minecraft:enchantments":{"minecraft:protection":1}}}},{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:gold_ingot",count:6,components:{"minecraft:item_name":{"bold":true,"color":"yellow","italic":false,"text":"Gold"}}},sell:{id:"minecraft:chainmail_chestplate",count:1,components:{"minecraft:enchantments":{"minecraft:protection":3}}}},{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:gold_ingot",count:8,components:{"minecraft:item_name":{"bold":true,"color":"yellow","italic":false,"text":"Gold"}}},buyB:{id:"minecraft:netherite_ingot",count:1,components:{"minecraft:item_name":{"bold":true,"color":"dark_red","italic":false,"text":"Netherite"}}},sell:{id:"minecraft:iron_chestplate",count:1,components:{"minecraft:enchantments":{"minecraft:protection":3}}}}]}}
        summon villager 6.5 69 66.5 {NoGravity:1b,Invulnerable:1b,NoAI:1b,CanPickUpLoot:0b,Tags:["red","shop","armors"],CustomName:{"bold":true,"color":"gray","text":"Armors & Defenses"},VillagerData:{level:5,profession:"minecraft:armorer",type:"minecraft:plains"},Offers:{Recipes:[{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:iron_ingot",count:4,components:{"minecraft:item_name":{"bold":true,"color":"gray","italic":false,"text":"Iron"}}},sell:{id:"minecraft:chainmail_chestplate",count:1,components:{"minecraft:enchantments":{"minecraft:protection":1}}}},{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:gold_ingot",count:6,components:{"minecraft:item_name":{"bold":true,"color":"yellow","italic":false,"text":"Gold"}}},sell:{id:"minecraft:chainmail_chestplate",count:1,components:{"minecraft:enchantments":{"minecraft:protection":3}}}},{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:gold_ingot",count:8,components:{"minecraft:item_name":{"bold":true,"color":"yellow","italic":false,"text":"Gold"}}},buyB:{id:"minecraft:netherite_ingot",count:1,components:{"minecraft:item_name":{"bold":true,"color":"dark_red","italic":false,"text":"Netherite"}}},sell:{id:"minecraft:iron_chestplate",count:1,components:{"minecraft:enchantments":{"minecraft:protection":3}}}}]}}

    # WEAPONS
        summon villager -3.5 69 -65.5 {NoGravity:1b,Invulnerable:1b,NoAI:1b,CanPickUpLoot:0b,Tags:["blue","shop","swords"],CustomName:{"bold":true,"color":"red","text":"Swords & Bows"},VillagerData:{level:5,profession:"minecraft:weaponsmith",type:"minecraft:snow"},Offers:{Recipes:[{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:iron_ingot",count:4,components:{"minecraft:item_name":{bold:true,color:"gray",italic:false,text:"Iron"}}},sell:{id:"minecraft:stone_sword",count:1,components:{"minecraft:enchantments":{"minecraft:sharpness":1}}}},{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:gold_ingot",count:6,components:{"minecraft:item_name":{bold:true,color:"yellow",italic:false,text:"Gold"}}},sell:{id:"minecraft:iron_sword",count:1,components:{"minecraft:enchantments":{"minecraft:sharpness":2}}}},{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:gold_ingot",count:8,components:{"minecraft:item_name":{bold:true,color:"yellow",italic:false,text:"Gold"}}},buyB:{id:"minecraft:netherite_ingot",count:1,components:{"minecraft:item_name":{bold:true,color:"dark_red",italic:false,text:"Netherite"}}},sell:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:enchantments":{"minecraft:sharpness":3}}}}]}}
        summon villager 4.5 69 66.5 {NoGravity:1b,Invulnerable:1b,NoAI:1b,CanPickUpLoot:0b,Tags:["red","shop","swords"],CustomName:{"bold":true,"color":"red","text":"Swords & Bows"},VillagerData:{level:5,profession:"minecraft:weaponsmith",type:"minecraft:plains"},Offers:{Recipes:[{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:iron_ingot",count:4,components:{"minecraft:item_name":{bold:true,color:"gray",italic:false,text:"Iron"}}},sell:{id:"minecraft:stone_sword",count:1,components:{"minecraft:enchantments":{"minecraft:sharpness":1}}}},{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:gold_ingot",count:6,components:{"minecraft:item_name":{bold:true,color:"yellow",italic:false,text:"Gold"}}},sell:{id:"minecraft:iron_sword",count:1,components:{"minecraft:enchantments":{"minecraft:sharpness":2}}}},{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:gold_ingot",count:8,components:{"minecraft:item_name":{bold:true,color:"yellow",italic:false,text:"Gold"}}},buyB:{id:"minecraft:netherite_ingot",count:1,components:{"minecraft:item_name":{bold:true,color:"dark_red",italic:false,text:"Netherite"}}},sell:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:enchantments":{"minecraft:sharpness":3}}}}]}}

    # BLOCKS AND PICKAXES
        summon villager 4.5 69.0 -65.5 {NoGravity:1b,Invulnerable:1b,NoAI:1b,CanPickUpLoot:0b,Tags:["blue","shop","blocks"],CustomName:{"bold":true,"color":"yellow","text":"Blocks & Pickaxes"},VillagerData:{level:5,profession:"minecraft:mason",type:"minecraft:snow"},Offers:{Recipes:[{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:copper_ingot",count:1,components:{"minecraft:item_name":{"bold":true,"color":"gold","italic":false,"text":"Copper"}}},sell:{id:"minecraft:cut_sandstone",count:4}},{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:iron_ingot",count:1,components:{"minecraft:item_name":{"bold":true,"color":"gray","italic":false,"text":"Iron"}}},sell:{id:"minecraft:end_stone",count:1}},{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:iron_ingot",count:2,components:{"minecraft:item_name":{"bold":true,"color":"gray","italic":false,"text":"Iron"}}},sell:{id:"minecraft:stone_pickaxe",count:1,components:{"minecraft:enchantments":{"minecraft:efficiency":1}}}},{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:gold_ingot",count:6,components:{"minecraft:item_name":{bold:true,color:"yellow",italic:false,text:"Gold"}}},sell:{id:"minecraft:iron_pickaxe",count:1,components:{"minecraft:enchantments":{"minecraft:efficiency":2}}}},{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:gold_ingot",count:8,components:{"minecraft:item_name":{bold:true,color:"yellow",italic:false,text:"Gold"}}},buyB:{id:"minecraft:netherite_ingot",count:1,components:{"minecraft:item_name":{bold:true,color:"dark_red",italic:false,text:"Netherite"}}},sell:{id:"minecraft:diamond_pickaxe",count:1,components:{"minecraft:enchantments":{"minecraft:efficiency":3}}}}]}}
        summon villager -3.5 69.0 66.5 {NoGravity:1b,Invulnerable:1b,NoAI:1b,CanPickUpLoot:0b,Tags:["red","shop","blocks"],CustomName:{"bold":true,"color":"yellow","text":"Blocks & Pickaxes"},VillagerData:{level:5,profession:"minecraft:mason",type:"minecraft:plains"},Offers:{Recipes:[{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:copper_ingot",count:1,components:{"minecraft:item_name":{"bold":true,"color":"gold","italic":false,"text":"Copper"}}},sell:{id:"minecraft:cut_sandstone",count:4}},{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:iron_ingot",count:1,components:{"minecraft:item_name":{"bold":true,"color":"gray","italic":false,"text":"Iron"}}},sell:{id:"minecraft:end_stone",count:1}},{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:iron_ingot",count:2,components:{"minecraft:item_name":{"bold":true,"color":"gray","italic":false,"text":"Iron"}}},sell:{id:"minecraft:stone_pickaxe",count:1,components:{"minecraft:enchantments":{"minecraft:efficiency":1}}}},{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:gold_ingot",count:6,components:{"minecraft:item_name":{bold:true,color:"yellow",italic:false,text:"Gold"}}},sell:{id:"minecraft:iron_pickaxe",count:1,components:{"minecraft:enchantments":{"minecraft:efficiency":2}}}},{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:gold_ingot",count:8,components:{"minecraft:item_name":{bold:true,color:"yellow",italic:false,text:"Gold"}}},buyB:{id:"minecraft:netherite_ingot",count:1,components:{"minecraft:item_name":{bold:true,color:"dark_red",italic:false,text:"Netherite"}}},sell:{id:"minecraft:diamond_pickaxe",count:1,components:{"minecraft:enchantments":{"minecraft:efficiency":3}}}}]}}
    
    # MISC
        summon villager 6.5 69.0 -65.5 {NoGravity:1b,Invulnerable:1b,NoAI:1b,CanPickUpLoot:0b,Tags:["blue","shop","misc"],CustomName:{"bold":true,"color":"gold","text":"Food & Tools"},VillagerData:{level:5,profession:"minecraft:butcher",type:"minecraft:snow"},Offers:{Recipes:[{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:copper_ingot",count:4,components:{"minecraft:item_name":{"bold":true,"color":"gold","italic":false,"text":"Copper"}}},sell:{id:"minecraft:cooked_beef",count:2}},{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:gold_ingot",count:2,components:{"minecraft:item_name":{"bold":true,"color":"yellow","italic":false,"text":"Gold"}}},sell:{id:"minecraft:golden_apple",count:1}}]}}
        summon villager -5.5 69.0 66.5 {NoGravity:1b,Invulnerable:1b,NoAI:1b,CanPickUpLoot:0b,Tags:["red","shop","misc"],CustomName:{"bold":true,"color":"gold","text":"Food & Tools"},VillagerData:{level:5,profession:"minecraft:butcher",type:"minecraft:plains"},Offers:{Recipes:[{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:copper_ingot",count:4,components:{"minecraft:item_name":{"bold":true,"color":"gold","italic":false,"text":"Copper"}}},sell:{id:"minecraft:cooked_beef",count:2}},{rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:gold_ingot",count:2,components:{"minecraft:item_name":{"bold":true,"color":"yellow","italic":false,"text":"Gold"}}},sell:{id:"minecraft:golden_apple",count:1}}]}}

    # ADD TRADES DEPENDING ON OPTIONS
        # ARMORS
            execute if score shield ar_options matches 1 as @e[type=villager,tag=shop,tag=armors] run data modify entity @s Offers.Recipes append value {rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:iron_ingot",count:8,components:{"minecraft:item_name":{"bold":true,"color":"gray","italic":false,"text":"Iron"}}},sell:{id:"minecraft:shield",count:1}}
            execute if score totem ar_options matches 1 as @e[type=villager,tag=shop,tag=armors] run data modify entity @s Offers.Recipes append value {rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:gold_ingot",count:6,components:{"minecraft:item_name":{"bold":true,"color":"yellow","italic":false,"text":"Gold"}}},buyB:{id:"minecraft:netherite_ingot",count:2,components:{"minecraft:item_name":{"bold":true,"color":"dark_red","italic":false,"text":"Netherite"}}},sell:{id:"minecraft:totem_of_undying",count:1}}

        # WEAPONS
            execute if score bows ar_options matches 1 as @e[type=villager,tag=shop,tag=swords] run data modify entity @s Offers.Recipes append value {rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:iron_ingot",count:8,components:{"minecraft:item_name":{bold:true,color:"gray",italic:false,text:"Iron"}}},sell:{id:"minecraft:bow",count:1,components:{"minecraft:enchantments":{"minecraft:infinity":1}}}}
            execute if score bows ar_options matches 1 as @e[type=villager,tag=shop,tag=swords] run data modify entity @s Offers.Recipes append value {rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:gold_ingot",count:12,components:{"minecraft:item_name":{bold:true,color:"yellow",italic:false,text:"Gold"}}},buyB:{id:"minecraft:netherite_ingot",count:1,components:{"minecraft:item_name":{bold:true,color:"dark_red",italic:false,text:"Netherite"}}},sell:{id:"minecraft:bow",count:1,components:{"minecraft:enchantments":{"minecraft:power":3,"minecraft:punch":1,"minecraft:infinity":1}}}}
            execute if score bows ar_options matches 1 as @e[type=villager,tag=shop,tag=swords] run data modify entity @s Offers.Recipes append value {rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:gold_ingot",count:8,components:{"minecraft:item_name":{bold:true,color:"yellow",italic:false,text:"Gold"}}},sell:{id:"minecraft:bow",count:1,components:{"minecraft:enchantments":{"minecraft:power":2,"minecraft:infinity":1}}}}

        # MISC
            execute if score tnt ar_options matches 1 as @e[type=villager,tag=shop,tag=misc] run data modify entity @s Offers.Recipes append value {rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:iron_ingot",count:4,components:{"minecraft:item_name":{"bold":true,"color":"gray","italic":false,"text":"Iron"}}},sell:{id:"minecraft:tnt",count:1}}
            execute if score tnt ar_options matches 1 as @e[type=villager,tag=shop,tag=misc] run data modify entity @s Offers.Recipes append value {rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:gold_ingot",count:2,components:{"minecraft:item_name":{"bold":true,"color":"yellow","italic":false,"text":"Gold"}}},buyB:{id:"minecraft:netherite_ingot",count:1,components:{"minecraft:item_name":{"bold":true,"color":"dark_red","italic":false,"text":"Netherite"}}},sell:{id:"minecraft:flint_and_steel",count:1}}
            execute if score bows ar_options matches 1 as @e[type=villager,tag=shop,tag=misc] run data modify entity @s Offers.Recipes append value {rewardExp:0b,maxUses:2147483647,buy:{id:"minecraft:netherite_ingot",count:1,components:{"minecraft:item_name":{"bold":true,"color":"dark_red","italic":false,"text":"Netherite"}}},sell:{id:"minecraft:arrow",count:1}}

# ALL ENTITIES LOOK AT CENTER
    execute as @e[tag=blue] at @s run tp @s ~ ~ ~ 0 0
    execute as @e[tag=red] at @s run tp @s ~ ~ ~ 180 0

# WORLD SPAWN
    setworldspawn 0 69 0

# UPDATE PLAYERS
    # TEAMS
        team join ar_teamBlue @a
        team join ar_teamRed @r

    # GAMEMODE
        gamemode survival @a

    # INVENTORIES
        clear @a
        execute as @a run function ar:ingame/clear_ec
        execute as @a run function ar:ingame/equip_armor

    # EFFECTS
        effect clear @a
        effect give @a minecraft:regeneration 6 255 true

    # TELEPORTATIONS
        tp @a[team=ar_teamBlue] 0.5 69.0 -58.5 180 20
        tp @a[team=ar_teamRed] 0.5 69.0 59.5 0 20

# TELLRAW
    tellraw @a [{"bold":true,"color":"dark_gray","text":"["},{"bold":false,"color":"white","text":"Akan"},{"bold":true,"color":"gold","text":"RUSH"},{"bold":true,"color":"dark_gray","text":"] "},{"bold":false,"color":"white","text":"Game start now!"}]

# TITLES
    title @a title {"color":"gold","text":"Game start now!"}
    title @a subtitle [{"bold":true,"color":"dark_gray","text":"["},{"bold":false,"color":"white","text":"Akan"},{"bold":true,"color":"gold","text":"RUSH"},{"bold":true,"color":"dark_gray","text":"]"}]