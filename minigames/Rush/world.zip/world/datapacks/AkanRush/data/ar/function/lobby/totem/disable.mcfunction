# SCOREBOARDS
    scoreboard players set totem ar_options 0

# BLOCKS
    setblock 6 201 -4 obsidian
    data modify block 5 201 -4 front_text.messages[2] set value {"text":"Off","color":"red","bold":true,"click_event":{"action":"run_command","command":"function ar:lobby/totem/enable"}}

# SOUNDS
    execute if score doSounds ar_options matches 1 positioned 5 201 -4 run playsound entity.pillager.death master @a ~ ~ ~ 1 1 1