# REMOVE OLD
	# LOBBY
		team empty ar_lobbyPlayer
		team remove ar_lobbyPlayer

	# IN GAME
		team empty ar_teamBlue
		team remove ar_teamBlue
		
		team empty ar_teamRed
		team remove ar_teamRed
		
		team empty ar_dead
		team remove ar_dead

# ADD NEW
	# LOBBY
		team add ar_lobbyPlayer

	# IN GAME
		team add ar_teamBlue
		team add ar_teamRed
		team add ar_dead

# SETUP
	# LOBBY
		team modify ar_lobbyPlayer color gray
		team modify ar_lobbyPlayer friendlyFire false

	# IN GAME
		team modify ar_teamBlue color blue
		team modify ar_teamRed color red
		team modify ar_dead color gray