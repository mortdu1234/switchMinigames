# TIMER
    scoreboard players add ticks ar_timer 1
    execute if score ticks ar_timer matches 20.. run scoreboard players add seconds ar_timer 1
    execute if score seconds ar_timer matches 60.. run scoreboard players add minutes ar_timer 1

# RESSOURCES ITEMS
    execute as @e[tag=spawned,x=.5,y=68.0,z=-64.5,distance=..0.5] run data merge entity @s {Motion:[.0,.0,.0]}
    execute as @e[tag=spawned,x=.5,y=68.0,z=-64.5,distance=..0.5] run tag @s remove spawned

    execute as @e[tag=spawned,x=.5,y=68.0,z=65.5,distance=..0.5] run data merge entity @s {Motion:[.0,.0,.0]}
    execute as @e[tag=spawned,x=.5,y=68.0,z=65.5,distance=..0.5] run tag @s remove spawned

    # BRONZE
        execute as @e[tag=spawner] at @s positioned ^1 ^ ^ if score ticks ar_timer matches 20.. run summon item ~ ~ ~ {Age:-32768,PickupDelay:0,Invulnerable:1b,Tags:["spawned","ressource"],Item:{id:"minecraft:copper_ingot",count:1,components:{"minecraft:item_name":{"bold":true,"color":"gold","italic":false,"text":"Copper"},"minecraft:custom_data":{ressource:1b}}}}

    # SILVER
        scoreboard players operation temp ar_timer = seconds ar_timer
        scoreboard players operation temp ar_timer %= 3 ar_constants
        execute as @e[tag=spawner] at @s positioned ^1 ^ ^ if score ticks ar_timer matches 20.. if score temp ar_timer matches 0 run summon item ~ ~ ~ {Age:-32768,PickupDelay:0,Invulnerable:1b,Tags:["spawned","ressource"],Item:{id:"minecraft:iron_ingot",count:1,components:{"minecraft:item_name":{"bold":true,"color":"gray","italic":false,"text":"Iron"},"minecraft:custom_data":{ressource:1b}}}}
        scoreboard players reset temp ar_timer

    # GOLD
        scoreboard players operation temp ar_timer = seconds ar_timer
        scoreboard players operation temp ar_timer %= 15 ar_constants
        execute as @e[tag=spawner] at @s positioned ^-1 ^ ^ if score ticks ar_timer matches 20.. if score temp ar_timer matches 0 run summon item ~ ~ ~ {Age:-32768,PickupDelay:0,Invulnerable:1b,Tags:["spawned","ressource"],Item:{id:"minecraft:gold_ingot",count:1,components:{"minecraft:item_name":{"bold":true,"color":"yellow","italic":false,"text":"Gold"},"minecraft:custom_data":{ressource:1b}}}}
        scoreboard players reset temp ar_timer

    # NETHERITE
        execute as @e[tag=spawner] at @s positioned ^-1 ^ ^ if score ticks ar_timer matches 20.. if score seconds ar_timer matches 60.. if score minutes ar_timer matches 2.. run summon item ~ ~ ~ {Age:-32768,PickupDelay:0,Invulnerable:1b,Tags:["spawned","ressource","rare"],Item:{id:"minecraft:netherite_ingot",count:1,components:{"minecraft:item_name":{"bold":true,"color":"dark_red","italic":false,"text":"Netherite"},"minecraft:custom_data":{ressource:1b,rare:1b}}}}
        
        execute if score animations ar_options matches 1 run scoreboard players set canRandom ar_random 0
        execute if score animations ar_options matches 1 run scoreboard players set random ar_random -1
        execute if score animations ar_options matches 1 run execute if entity @e[tag=rare] run scoreboard players set canRandom ar_random 1
        execute if score animations ar_options matches 1 run execute if entity @e[nbt={Item:{components:{"minecraft:custom_data":{rare:1b}}}}] run scoreboard players set canRandom ar_random 1
        execute if score animations ar_options matches 1 run execute if score canRandom ar_random matches 1 store result score random ar_random run random value 0..99

        execute if score animations ar_options matches 1 run execute if score random ar_random matches 99 as @e[tag=rare] run data merge entity @s {Motion:[.0,.3,.0]}
        execute if score animations ar_options matches 1 run execute if score random ar_random matches 0..5 as @e[nbt={Item:{components:{"minecraft:custom_data":{rare:1b}}}}] at @s run particle trial_spawner_detection_ominous ~ ~.5 ~ .2 0 .2 0 1 force @a

# DEATH
    execute as @a if score @s ar_death matches 1.. run scoreboard players add @s ar_deathHUD 1
    execute as @a if score @s ar_death matches 1.. run scoreboard players set @s ar_death 0

# RESPAWN
    execute as @a if score @s ar_sinceDeath matches 1 unless data entity @s respawn.pos run function ar:ingame/lose
    execute as @a if score @s ar_sinceDeath matches 1 run function ar:ingame/equip_armor

# PREVENT BREAKING PLATFORM BLOCKS
    execute as @e[type=marker,tag=ar_obsidian] at @s if block ~ ~ ~ air run setblock ~ ~ ~ obsidian
    execute as @e[type=marker,tag=ar_ec] at @s if block ~ ~ ~ air run setblock ~ ~ ~ ender_chest
    execute as @e[type=marker,tag=ar_bulb] at @s if block ~ ~ ~ air run setblock ~ ~ ~ waxed_copper_bulb[lit=true]
    execute as @e[type=marker,tag=ar_rod] at @s if block ~ ~ ~ air run setblock ~ ~ ~ end_rod[facing=down]

# ESCAPING PLAYERS
    execute as @a unless entity @s[x=-98,y=-64,z=-98,dx=197,dy=383,dz=197] run gamemode adventure @s
    execute as @a[gamemode=adventure] if entity @s[x=-98,y=-64,z=-98,dx=197,dy=383,dz=197] run gamemode survival @s

# RESET TIMER
    execute if score ticks ar_timer matches 20.. run scoreboard players set ticks ar_timer 0
    execute if score seconds ar_timer matches 60.. run scoreboard players set seconds ar_timer 0
    execute if score minutes ar_timer matches 2.. run scoreboard players set minutes ar_timer 0