# SPECTATE
    # MESSAGE
        execute as @a[scores={ar_spectate=1}] run tellraw @s [{"bold":true,"color":"white","text":"Click "},{"bold":true,"click_event":{"action":"run_command","command":"trigger ar_spectate add 1"},"color":"green","hover_event":{"action":"show_text","value":[{"text":"Click me!","color":"yellow","italic":true}]},"text":"[HERE]"},{"bold":true,"color":"white","text":" to get back in the "},{"bold":true,"color":"green","hover_event":{"action":"show_text","value":[{"text":"","color":"yellow","italic":true}]},"text":"lobby"},{"bold":true,"color":"white","text":"."}]

    # UPDATE PLAYER
        execute as @a[scores={ar_spectate=1}] run tp @s 0 196 0 90 90
        execute as @a[scores={ar_spectate=1}] run gamemode spectator @s

    # SCOREBOARD
        execute as @a[scores={ar_spectate=1}] run scoreboard players add @s ar_spectate 1

# UNSPECTATE
    # UPDATE PLAYER
        execute as @a[scores={ar_spectate=3}] run tp @s 0 200 0 0 0
        execute as @a[scores={ar_spectate=3}] run gamemode adventure @s

    # SCOREBOARD
        execute as @a[scores={ar_spectate=3}] run scoreboard players set @s ar_spectate 0