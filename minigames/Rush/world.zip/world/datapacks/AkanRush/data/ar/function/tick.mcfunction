execute if score lobby ar_state matches 1 run function ar:lobby/tick
execute if score inGame ar_state matches 1 run function ar:ingame/tick
execute if score endGame ar_state matches 1 run function ar:endgame/tick