# SCOREBOARDS
    scoreboard players set bows ar_options 0

# BLOCKS
    setblock 6 201 0 obsidian
    data modify block 5 201 0 front_text.messages[2] set value {"text":"Off","color":"red","bold":true,"click_event":{"action":"run_command","command":"function ar:lobby/bows/enable"}}

# SOUNDS
    execute if score doSounds ar_options matches 1 positioned 5 201 0 run playsound entity.arrow.shoot master @a ~ ~ ~ 1 1 1