# NEW CONNECTED PLAYER
    # TELEPORTATION
        execute as @a[team=!ar_lobbyPlayer] run tp @s 0.5 200.0 0.5 0 0

    # GAMEMODE
        execute as @a[team=!ar_lobbyPlayer] run gamemode adventure @s

    # INVENTORIES
        execute as @a[team=!ar_lobbyPlayer] run clear @s
        execute as @a[team=!ar_lobbyPlayer] run function ar:ingame/clear_ec

    # EFFECTS
        execute as @a[team=!ar_lobbyPlayer] run effect clear @s
        execute as @a[team=!ar_lobbyPlayer] run effect give @s minecraft:regeneration 6 255 true
        execute as @a[team=!ar_lobbyPlayer] run effect give @s minecraft:saturation infinite 255 true

    # TEAM
        execute as @a[team=!ar_lobbyPlayer] run team join ar_lobbyPlayer

    # SPECTATE SYSTEM
        scoreboard players enable @a ar_spectate
        function ar:lobby/spectate

# WORLD
    time set 6000