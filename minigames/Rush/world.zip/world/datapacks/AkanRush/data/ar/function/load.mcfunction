function ar:setup/gamerules
function ar:setup/scoreboards
function ar:setup/teams
function ar:setup/general

function ar:setup/lobby

tellraw @a[gamemode=creative] [{"text":"[LOADED] ","color":"green","bold":true},{"text":"AkanRush ","color":"gray","bold":false},{"text":"- by Akanlyfe","color":"gray","bold":false,"italic":true}]