# BLUE
    item replace entity @s[team=ar_teamBlue] armor.head with leather_helmet[dyed_color=3949738,item_name={"bold":true,"color":"blue","italic":false,"text":"Blue Team"}] 1
    item replace entity @s[team=ar_teamBlue] armor.legs with leather_leggings[dyed_color=3949738,item_name={"bold":true,"color":"blue","italic":false,"text":"Blue Team"}] 1
    item replace entity @s[team=ar_teamBlue] armor.feet with leather_boots[dyed_color=3949738,item_name={"bold":true,"color":"blue","italic":false,"text":"Blue Team"}] 1

# RED
    item replace entity @s[team=ar_teamRed] armor.head with leather_helmet[dyed_color=11546150,item_name={"bold":true,"color":"red","italic":false,"text":"Red Team"}] 1
    item replace entity @s[team=ar_teamRed] armor.legs with leather_leggings[dyed_color=11546150,item_name={"bold":true,"color":"red","italic":false,"text":"Red Team"}] 1
    item replace entity @s[team=ar_teamRed] armor.feet with leather_boots[dyed_color=11546150,item_name={"bold":true,"color":"red","italic":false,"text":"Red Team"}] 1