# TIMER
    scoreboard players add ticks ar_timer 1
    execute if score ticks ar_timer matches 20.. run scoreboard players add seconds ar_timer 1

# FIREWORKS
    # BLUE
        execute if score ticks ar_timer matches 20.. at @a[team=ar_teamBlue] run summon firework_rocket ~ ~2 ~ {LifeTime:40,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{explosions:[{shape:"large_ball",has_twinkle:true,has_trail:true,colors:[I;255],fade_colors:[I;16777215]},{shape:"small_ball",has_twinkle:true,has_trail:true,colors:[I;7697919],fade_colors:[I;16777215]}]}}}}

    # RED
        execute if score ticks ar_timer matches 20.. at @a[team=ar_teamRed] run summon firework_rocket ~ ~2 ~ {LifeTime:40,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{explosions:[{shape:"large_ball",has_twinkle:true,has_trail:true,colors:[I;16711680],fade_colors:[I;16777215]},{shape:"small_ball",has_twinkle:true,has_trail:true,colors:[I;16742520],fade_colors:[I;16777215]}]}}}}

# UPDATE STATES
    execute if score seconds ar_timer matches 10.. run scoreboard players set lobby ar_state 1
    execute if score seconds ar_timer matches 10.. run scoreboard players set endGame ar_state 0
    execute if score seconds ar_timer matches 10.. run function ar:setup/lobby

# RESET TIMER
    execute if score ticks ar_timer matches 20.. run scoreboard players set ticks ar_timer 0