# REMOVE OLD
	scoreboard objectives remove ar_constants

	scoreboard objectives remove ar_state

	scoreboard objectives remove ar_options
	scoreboard objectives remove ar_spectate

	scoreboard objectives remove ar_timer

	scoreboard objectives remove ar_random

	scoreboard objectives remove ar_playerCount

	scoreboard objectives remove ar_death
	scoreboard objectives remove ar_deathHUD
	scoreboard objectives remove ar_sinceDeath

# ADD NEW
	scoreboard objectives add ar_constants dummy

	scoreboard objectives add ar_state dummy

	scoreboard objectives add ar_options dummy
	scoreboard objectives add ar_spectate trigger
	
	scoreboard objectives add ar_timer dummy

	scoreboard objectives add ar_random dummy

	scoreboard objectives add ar_playerCount dummy

	scoreboard objectives add ar_death deathCount
	scoreboard objectives add ar_deathHUD dummy ["Deaths"]
	scoreboard objectives add ar_sinceDeath custom:minecraft.time_since_death

# SETUP
	scoreboard players set 3 ar_constants 3
	scoreboard players set 15 ar_constants 15

	scoreboard players set lobby ar_state 1
	scoreboard players set inGame ar_state 0
	scoreboard players set endGame ar_state 0

	scoreboard players set doSounds ar_options 0
	scoreboard players set totem ar_options 1
	scoreboard players set shield ar_options 1
	scoreboard players set bows ar_options 1
	scoreboard players set tnt ar_options 1
	scoreboard players set animations ar_options 1

	scoreboard players set @a ar_spectate 0

	scoreboard players set ticks ar_timer 0
	scoreboard players set seconds ar_timer 0
	scoreboard players set minutes ar_timer 0

	scoreboard players set canRandom ar_random 0
	scoreboard players set random ar_random -1

	scoreboard players set blue ar_playerCount 0
	scoreboard players set red ar_playerCount 0

	scoreboard players set @a ar_death 0
	scoreboard players set @a ar_deathHUD 0