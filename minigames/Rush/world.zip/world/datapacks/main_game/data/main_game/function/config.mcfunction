# =========================================================
#   Main Game -- Config
# =========================================================
# Relance cette fonction pour (re)initialiser la config :
#   /function main_game:config
#
# Puis modifie une valeur avec :
#   /scoreboard players set <clé> main_game_cfg <valeur>
#
# CLÉS DISPONIBLES :
#  game_time                    durée de la partie en sec                               (def: 12000)
#  hunter_number                nombre de chasseur pour la partie                       (def: 1)
#  time_before_hunter_free      durée avant laquel les hunters sont laché en sec        (def: 400)
#  time_refill                  durée entre chaque refill des coffres                   (def: 6000)
#  random_hunter                est ce que les hunter sont random (0: false|1: true)    (def: 1)
#  cake_ratio                   % d'apparition de gateau lors de la génération          (def: 10)
#  
# =========================================================
scoreboard players set game_time main_game_cfg 100 
scoreboard players set hunter_number main_game_cfg 1
scoreboard players set time_before_hunter_free main_game_cfg 20
scoreboard players set time_refill main_game_cfg 10
scoreboard players set random_hunter main_game_cfg 1
scoreboard players set cake_ratio main_game_cfg 10
 