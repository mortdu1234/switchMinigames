
#Makers Spleef II - Copyright (c) MineMakers Team (by Aksiome)

scoreboard players set @s pickaxe 3