
#Makers Spleef II - Copyright (c) MineMakers Team (by Aksiome)

particle flame ~ ~ ~ 0 0 0 0.07 4
scoreboard players add @s var 1
execute at @s[scores={var=3..}] run fill ~1 ~1 ~1 ~-1 ~-2 ~-1 air replace #game:terracotta