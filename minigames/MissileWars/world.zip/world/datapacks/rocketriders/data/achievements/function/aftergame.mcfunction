scoreboard players add @a[x=0,tag=Winner] wins 1
scoreboard players add @a[x=0,tag=Loser] losses 1
execute as @a[x=0,tag=Winner] run function custom:player_action/playerdata/save
execute as @a[x=0,tag=Loser] run function custom:player_action/playerdata/save

##Any achievements to be given by the official end of a match.
##The execution of this function may be delayed for the Tie/Tiebreaker window.
#| || || |_
scoreboard players add @a[x=0,tag=Winner] WinStreak 1
advancement grant @a[x=0,scores={WinStreak=10..},tag=Loser] only achievements:rr_challenges/loss
scoreboard players reset @a[x=0,tag=Loser] WinStreak

#Swiss Cheese (part 2)
advancement grant @a[x=0,tag=SwissCheese,tag=Winner] only achievements:rr_challenges/swiss_cheese
tag @a[x=0] remove SwissCheese

#Simple And Clean (part 2)
advancement grant @a[x=0,tag=SimpleAndClean,tag=Winner] only achievements:rr_challenges/simple_and_clean
tag @a[x=0] remove SimpleAndClean

#Deus Ex Machina (part 2)
advancement grant @a[x=0,tag=DeusExMachina,tag=Winner] only achievements:rr_challenges/machina
tag @a[x=0] remove DeusExMachina

#I Swear I Had It (part 2)
advancement grant @a[x=0,tag=HadIt,tag=Loser] only achievements:rr_challenges/had_it
scoreboard players reset @a[x=0] HasMissiles
tag @a[x=0] remove HadIt

#One is the Loneliest Number (part 2)
advancement grant @a[x=0,tag=Loneliest,tag=Winner] only achievements:rr_challenges/loneliest
tag @a[x=0] remove Loneliest

#Forsaken (part 2)
advancement grant @a[x=0,tag=Forsaken,tag=Winner] only achievements:rr_challenges/forsaken
tag @a[x=0] remove Forsaken

#Ground Bound (part 2)
advancement grant @a[x=0,tag=GroundBound,tag=Winner] only achievements:rr_challenges/groundbound
tag @a[x=0] remove GroundBound

#Immortal (part 2) - applies to both winners/losers but only if win/loss still stands
execute as @a[x=0,predicate=custom:team/any_playing_team] unless score @s match_statistic.deaths matches 1.. unless entity @s[tag=!Winner,tag=!Loser] run advancement grant @s only achievements:rr_challenges/immortal

#Ballet Dancer - applies to both winners/losers but only if win/loss still stands
execute as @a[x=0,tag=!FailedBallet,tag=firstMoved] unless entity @s[tag=!Winner,tag=!Loser] run advancement grant @s only achievements:rr_challenges/ballet

#Moonwalker - applies to both winners/losers but only if win/loss still stands
execute as @a[x=0,tag=!FailedMoon,tag=firstMoved] unless entity @s[tag=!Winner,tag=!Loser] run advancement grant @s only achievements:rr_challenges/moonwalker

#Pacifist - works since players can't get kills after game end
execute as @a[x=0,tag=Winner] unless score @s match_statistic.kills matches 1.. run advancement grant @s only achievements:rr_challenges/pacifist

#I'm Helping! - works since players can't spawn missiles after game end
advancement grant @a[x=0,tag=Winner,scores={AuxSpawned=0,AntsSpawned=0,BladeSpawned=0,BroadSpawned=0,BSurpriseSpawned=0,BulletSpawned=0,CataSpawned=0,CitaSpawned=0,DuplexSpawned=0,GemiSpawned=0,GuardSpawned=0,HurSpawned=0,HyperSpawned=0,JugbSpawned=0,LifterSpawned=0,NullSpawned=0,RifterSpawned=0,SlashSpawned=0,ThunSpawned=0,TomaSpawned=0,WarSpawned=0,YSurpriseSpawned=0}] only achievements:rr_challenges/helping
