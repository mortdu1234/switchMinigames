fill 31 -64 -33 48 180 -16 air strict
scoreboard players set $chunk_clear_progress global 11
scoreboard players reset #chunk_clear_inactive_ticks global
