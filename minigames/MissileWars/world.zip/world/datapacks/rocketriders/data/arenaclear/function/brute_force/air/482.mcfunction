fill -163 -64 -129 -160 180 -112 air strict
scoreboard players set $chunk_clear_progress global 97
scoreboard players reset #chunk_clear_inactive_ticks global
