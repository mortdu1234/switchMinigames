fill 111 -64 -175 128 180 -160 air strict
scoreboard players set $chunk_clear_progress global 95
scoreboard players reset #chunk_clear_inactive_ticks global
