fill -113 -64 -17 -96 180 0 air strict
scoreboard players set $chunk_clear_progress global 53
scoreboard players reset #chunk_clear_inactive_ticks global
