fill -17 -64 159 0 180 175 air strict
scoreboard players set $chunk_clear_progress global 79
scoreboard players reset #chunk_clear_inactive_ticks global
