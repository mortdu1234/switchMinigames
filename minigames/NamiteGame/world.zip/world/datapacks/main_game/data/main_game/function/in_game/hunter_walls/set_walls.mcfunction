# positionner les murs 
fill -8 -8 -208 -8 -1 -210 minecraft:red_concrete
fill -1 -1 -215 -3 -8 -215 minecraft:red_concrete
fill 4 -8 -210 4 -1 -208 minecraft:red_concrete
fill -3 -1 -203 -1 -8 -203 minecraft:red_concrete