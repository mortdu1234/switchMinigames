# tourne chaque tick (20x/sec) -> on ne déclenche update_view qu'1x par seconde
scoreboard players add #tick_counter main_game_info 1

execute if score #tick_counter main_game_info matches 20.. run function main_game:in_game/update_view
execute if score #tick_counter main_game_info matches 20.. run scoreboard players set #tick_counter main_game_info 0

# ===== AFFICHAGE DYNAMIQUE (lit la vraie valeur dans main_game_info en live) =====
scoreboard players display numberformat §a▶ Cachés restants main_game_view fixed [{"score":{"name":"hide_count","objective":"main_game_info"}}]
scoreboard players display numberformat §c▶ Chasseurs main_game_view fixed [{"score":{"name":"hunter_count","objective":"main_game_info"}}]
scoreboard players display numberformat §e⏱ Fin de partie - min main_game_view fixed [{"score":{"name":"end_min","objective":"main_game_info"}}]
scoreboard players display numberformat §e⏱ Fin de partie - sec main_game_view fixed [{"score":{"name":"end_sec","objective":"main_game_info"}}]
scoreboard players display numberformat §b⏳ Refill - min main_game_view fixed [{"score":{"name":"ref_min","objective":"main_game_info"}}]
scoreboard players display numberformat §b⏳ Refill - sec main_game_view fixed [{"score":{"name":"ref_sec","objective":"main_game_info"}}]

# vérification de la victoire
function main_game:in_game/check_victory

# vérification des murs
execute if score time_before_hunter_free main_game_info matches 0 run function main_game:in_game/hunter_walls/remove_walls

# vérification de la mort
execute as @a[scores={main_game_death=1..}, team=hide] run function main_game:in_game/on_hide_killed