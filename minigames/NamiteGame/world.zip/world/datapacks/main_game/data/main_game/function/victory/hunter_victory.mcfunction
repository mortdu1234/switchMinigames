say victoire des hunters

function main_game:victory/commun_victory