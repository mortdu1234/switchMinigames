scoreboard players set @s main_game_class_hide_classic 0
scoreboard players set @s main_game_class_hide_invisible 0
scoreboard players set @s main_game_class_hide_smoker 0

$scoreboard players set @s main_game_class_hide_$(scoreboard) 1
$tellraw @s ["",{text:"tu as choisit le kit $(scoreboard)",color:"white"}]