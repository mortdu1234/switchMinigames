scoreboard players set #game_running main_game_cfg 0

scoreboard objectives remove main_game_info
scoreboard objectives remove main_game_view

scoreboard objectives add main_game_info dummy
scoreboard objectives add main_game_view dummy

kill @e[type=armor_stand]

tp @a 0 1 0
team leave @a

effect clear @a