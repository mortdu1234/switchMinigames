function teamloot:setblock
