setblock ~ ~ ~ chiseled_tuff_bricks
setblock ~ ~1 ~ cake
