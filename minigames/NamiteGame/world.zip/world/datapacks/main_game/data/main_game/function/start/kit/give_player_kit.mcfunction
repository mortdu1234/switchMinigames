# test pour les kits hide
execute as @a[team=hide] run function main_game:start/kit/hide/commun
execute as @a[team=hide, scores={main_game_class_hide_classic=1}] run function main_game:start/kit/hide/classic
execute as @a[team=hide, scores={main_game_class_hide_invisible=1}] run function main_game:start/kit/hide/invisible
execute as @a[team=hide, scores={main_game_class_hide_smoker=1}] run function main_game:start/kit/hide/smoker


# test pour les kits hunter
execute as @a[team=hunter] run function main_game:start/kit/hunter/commun
execute as @a[team=hunter, scores={main_game_class_hunter_classic=1}] run function main_game:start/kit/hunter/classic
execute as @a[team=hunter, scores={main_game_class_hunter_archer=1}] run function main_game:start/kit/hunter/archer
execute as @a[team=hunter, scores={main_game_class_hunter_pyroman=1}] run function main_game:start/kit/hunter/pyroman
execute as @a[team=hunter, scores={main_game_class_hunter_spearman=1}] run function main_game:start/kit/hunter/spearman
execute as @a[team=hunter, scores={main_game_class_hunter_swordman=1}] run function main_game:start/kit/hunter/swordman
