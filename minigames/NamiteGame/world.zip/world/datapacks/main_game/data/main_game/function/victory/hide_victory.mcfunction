say victoire des cachées
function main_game:victory/commun_victory