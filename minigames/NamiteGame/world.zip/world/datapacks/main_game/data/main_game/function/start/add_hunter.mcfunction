
scoreboard players remove hunter_number main_game_info 1
execute as @r[team=!hunter] run team join hunter
say add un hunter
execute if score hunter_number main_game_info matches 1.. run function main_game:start/add_hunter
