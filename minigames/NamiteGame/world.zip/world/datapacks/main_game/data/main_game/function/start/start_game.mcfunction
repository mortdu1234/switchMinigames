# code lors du lancement d'une partie
# initialisation des zones de spawns
execute positioned -2 -8 -209 run function main_game:start/teleportation/summons/hunter
execute positioned -24 -8 -187 run function main_game:start/teleportation/summons/hide
execute positioned 20 -8 -187 run function main_game:start/teleportation/summons/hide
execute positioned -24 -8 -231 run function main_game:start/teleportation/summons/hide
execute positioned 20 -8 -231 run function main_game:start/teleportation/summons/hide
# initialisation des murs
function main_game:in_game/hunter_walls/set_walls

# initialisation des coffres
function main_game:in_game/refill/refill_chests

# clear inventaire
clear @a

# cacher les pseudo hide
team modify hide nametagVisibility hideForOtherTeams

# effets
effect give @a saturation infinite 1 true
effect give @a[team=hunter] resistance infinite 100 true
# ====================================================
# itinialisation des parametres de la partie
# ====================================================
execute if score random_hunter main_game_cfg matches 1 run function main_game:start/team_selector
scoreboard players set #game_running main_game_cfg 1

scoreboard objectives add main_game_death deathCount
# ====================================================
# initialisation des parametres de la partie
# ====================================================
# initialisation du temps
execute store result score tmp main_game_info run scoreboard players get time_before_hunter_free main_game_cfg
execute store result score game_time main_game_info run scoreboard players get game_time main_game_cfg
scoreboard players operation game_time main_game_info += tmp main_game_info

# initialisation de temps avant le départ des chasseur
execute store result score time_before_hunter_free main_game_info run scoreboard players get time_before_hunter_free main_game_cfg

# initialisation du temps de refill
scoreboard players operation time_refill main_game_info = time_refill main_game_cfg

# initialisation du compteur de tick (pour ne mettre à jour le sidebar qu'1x/sec)
scoreboard players set #tick_counter main_game_info 0

# teleportation des joueurs
function main_game:start/teleportation/teleportation

# ===== ORDRE STATIQUE DU SIDEBAR =====
# Le score ici ne sert qu'au TRI (jamais modifié ensuite). Plus haut = plus haut dans le sidebar.
# PAS DE GUILLEMETS : l'espace figuré (U+2007) n'est pas un séparateur, donc inutile et risqué.
scoreboard players set §a▶ Cachés restants main_game_view 6
scoreboard players set §c▶ Chasseurs main_game_view 5
scoreboard players set §e⏱ Fin de partie - min main_game_view 4
scoreboard players set §e⏱ Fin de partie - sec main_game_view 3
scoreboard players set §b⏳ Refill - min main_game_view 2
scoreboard players set §b⏳ Refill - sec main_game_view 1

function main_game:in_game/update_view

scoreboard objectives setdisplay sidebar main_game_view