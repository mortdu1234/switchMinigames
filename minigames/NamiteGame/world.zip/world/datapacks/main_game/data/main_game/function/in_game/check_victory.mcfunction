execute if score hide_count main_game_info matches ..0 run function main_game:victory/hunter_victory
execute if score game_time main_game_info matches ..0 run function main_game:victory/hide_victory