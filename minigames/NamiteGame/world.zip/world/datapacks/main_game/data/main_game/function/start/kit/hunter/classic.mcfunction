# element du kit de base de hunter
# stuff commun

# particularité
give @s crossbow[unbreakable={}]
give @s arrow 64
give @s spectral_arrow 2