# stuff en commun pour tous les hide
item replace entity @s armor.feet with minecraft:leather_boots[enchantments={feather_falling:255}]
effect give @s saturation 10 10
effect give @s regeneration 10 10