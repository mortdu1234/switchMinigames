# particularité
give @s minecraft:flint_and_steel[unbreakable={}]
effect give @s fire_resistance infinite 1 true