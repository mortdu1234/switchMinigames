$execute if score $(key) main_game_cfg matches 1.. run scoreboard players remove $(key) main_game_cfg 1

$tellraw @p ["",{text:"value :"},{score:{name:"$(key)",objective:"main_game_cfg"}}]