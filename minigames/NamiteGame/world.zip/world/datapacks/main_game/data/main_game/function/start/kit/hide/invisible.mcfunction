loot give @s loot teamloot:items/invisible_potion
