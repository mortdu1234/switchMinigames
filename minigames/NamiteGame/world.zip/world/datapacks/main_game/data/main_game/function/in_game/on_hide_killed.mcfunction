scoreboard players remove @s main_game_death 1

tellraw @a ["",{selector:"@s"},{text:"is dead",color:"dark_red"}]
team leave @s
