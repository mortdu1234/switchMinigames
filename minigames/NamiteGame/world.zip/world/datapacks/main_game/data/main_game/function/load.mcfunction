# Lancé une fois au chargement du datapack / du monde.
function main_game:remove

team add hunter
team add hide

team modify hide color blue
team modify hunter color red

execute as @a run advancement revoke @s only main_game:kill_hide_player

scoreboard objectives add main_game_info dummy
scoreboard objectives add main_game_cfg dummy
scoreboard objectives add main_game_view dummy

# --- Constantes utilisées pour les calculs (mm:ss) ---
scoreboard players set #const_20 main_game_cfg 20
scoreboard players set #const_60 main_game_cfg 60

# --- La variable de lancement de la boucle de jeux --
scoreboard players set #game_running main_game_cfg 0

# --- Affichage du sidebar ---
scoreboard objectives modify main_game_view displayname [{"text":"GAME INFO","bold":true,"color":"gold"}]

#---- gestion des kits --
scoreboard objectives add main_game_class_hunter_classic dummy
scoreboard objectives add main_game_class_hunter_archer dummy
scoreboard objectives add main_game_class_hunter_pyroman dummy
scoreboard objectives add main_game_class_hunter_spearman dummy
scoreboard objectives add main_game_class_hunter_swordman dummy

scoreboard objectives add main_game_class_hide_classic dummy
scoreboard objectives add main_game_class_hide_invisible dummy
scoreboard objectives add main_game_class_hide_smoker dummy

function main_game:config

