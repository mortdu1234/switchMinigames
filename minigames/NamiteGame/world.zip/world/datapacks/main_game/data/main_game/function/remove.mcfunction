team remove hide
team remove hunter
scoreboard objectives remove main_game_cfg
scoreboard objectives remove main_game_info
scoreboard objectives remove main_game_view