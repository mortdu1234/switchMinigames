# se fait appelelr 1 fois par secondes
# gestion des hunter
scoreboard players remove time_before_hunter_free main_game_info 1
# =========================
# Joueurs caches restants
# =========================
scoreboard players set hide_count main_game_info 0
execute as @a[team=hide] run scoreboard players add hide_count main_game_info 1

# =========================
# Joueurs chasseurs
# =========================
scoreboard players set hunter_count main_game_info 0
execute as @a[team=hunter] run scoreboard players add hunter_count main_game_info 1

# =========================
# Temps avant fin de partie (mm:ss)
# =========================
scoreboard players remove game_time main_game_info 1

scoreboard players operation end_min main_game_info = game_time main_game_info
scoreboard players operation end_min main_game_info /= #const_60 main_game_cfg

scoreboard players operation end_sec main_game_info = game_time main_game_info
scoreboard players operation end_sec main_game_info %= #const_60 main_game_cfg

# =========================
# Temps avant prochain refill (mm:ss)
# =========================
scoreboard players remove time_refill main_game_info 1
execute if score time_refill main_game_info matches 0 run function main_game:in_game/refill/refill_chests
execute if score time_refill main_game_info matches ..0 run scoreboard players operation time_refill main_game_info = time_refill main_game_cfg

scoreboard players operation ref_min main_game_info = time_refill main_game_info
scoreboard players operation ref_min main_game_info /= #const_60 main_game_cfg

scoreboard players operation ref_sec main_game_info = time_refill main_game_info
scoreboard players operation ref_sec main_game_info %= #const_60 main_game_cfg
