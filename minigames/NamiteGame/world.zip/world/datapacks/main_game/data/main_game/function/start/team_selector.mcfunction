
team leave @a

# récupère le nombre de chasseur a créer
execute store result score hunter_number main_game_info run scoreboard players get hunter_number main_game_cfg
function main_game:start/add_hunter

# ajoute tous les autres joueurs a la team hide
execute as @a[team=!hunter] run team join hide

