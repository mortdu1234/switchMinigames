# clear ce qu'il y a avant
function main_game:start/chests/clear

# Tire un nombre aléatoire entre 1 et 100
execute store result score roll_temp main_game_cfg run random value 1..100

# Si le tirage est <= cake_ratio, on spawn un gâteau
execute if score roll_temp main_game_cfg <= cake_ratio main_game_cfg run function main_game:start/chests/spawn_cake

# Sinon, on spawn un coffre
execute unless score roll_temp main_game_cfg <= cake_ratio main_game_cfg run function main_game:start/chests/spawn_barrel