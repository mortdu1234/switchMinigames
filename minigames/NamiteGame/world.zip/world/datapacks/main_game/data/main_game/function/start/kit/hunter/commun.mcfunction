# stuff en commun pour tous les chasseurs
effect give @s saturation infinite 1 true
effect give @s resistance infinite 1