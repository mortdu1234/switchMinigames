# positionner les murs 
fill -8 -8 -208 -8 -1 -210 minecraft:air
fill -1 -1 -215 -3 -8 -215 minecraft:air
fill 4 -8 -210 4 -1 -208 minecraft:air
fill -3 -1 -203 -1 -8 -203 minecraft:air

say les hunters sont libérés

scoreboard players remove time_before_hunter_free main_game_info 1