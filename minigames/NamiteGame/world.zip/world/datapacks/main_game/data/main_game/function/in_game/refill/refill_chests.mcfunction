function main_game:start/chests/place_all_chests

say refill des coffres
