# element du kit de base de hunter
# stuff commun

# particularité
give @s bow[unbreakable={}]
give @s arrow 64