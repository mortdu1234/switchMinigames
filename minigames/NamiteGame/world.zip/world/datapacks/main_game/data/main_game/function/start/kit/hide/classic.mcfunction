# element du kit de base de hide
