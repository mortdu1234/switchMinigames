summon armor_stand ~ ~ ~ {Invisible:true, Invulnerable:true, Tags:[hidespawn]}
