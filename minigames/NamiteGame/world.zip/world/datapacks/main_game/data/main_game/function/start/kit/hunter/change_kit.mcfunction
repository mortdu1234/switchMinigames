scoreboard players set @s main_game_class_hunter_archer 0
scoreboard players set @s main_game_class_hunter_classic 0
scoreboard players set @s main_game_class_hunter_pyroman 0
scoreboard players set @s main_game_class_hunter_swordman 0
scoreboard players set @s main_game_class_hunter_spearman 0

$scoreboard players set @s main_game_class_hunter_$(scoreboard) 1
$tellraw @s ["",{text:"tu as choisit le kit $(scoreboard)",color:"white"}]