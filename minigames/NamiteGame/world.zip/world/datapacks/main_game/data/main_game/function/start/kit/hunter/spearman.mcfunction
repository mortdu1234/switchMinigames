# stuff commun

# particularité
give @s minecraft:wooden_axe[enchantments={lunge:3}, unbreakable={}]
give @s minecraft:wooden_axe[enchantments={lunge:2}, unbreakable={}]
give @s minecraft:wooden_axe[enchantments={lunge:1}, unbreakable={}]