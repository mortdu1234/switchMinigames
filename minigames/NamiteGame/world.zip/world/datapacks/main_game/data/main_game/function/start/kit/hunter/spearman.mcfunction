# stuff commun

# particularité
give @s minecraft:wooden_spear[enchantments={lunge:3}, unbreakable={}]
give @s minecraft:wooden_spear[enchantments={lunge:2}, unbreakable={}]
give @s minecraft:wooden_spear[enchantments={lunge:1}, unbreakable={}]
give @s minecraft:wooden_spear[unbreakable={}]