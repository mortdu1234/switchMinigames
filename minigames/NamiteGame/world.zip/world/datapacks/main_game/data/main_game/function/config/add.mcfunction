$scoreboard players add $(key) main_game_cfg 1

$tellraw @p ["",{text:"value :"},{score:{name:"$(key)",objective:"main_game_cfg"}}]