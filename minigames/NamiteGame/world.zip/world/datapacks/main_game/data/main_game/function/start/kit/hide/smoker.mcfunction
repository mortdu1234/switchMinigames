loot give @s loot smoke:smoke_bomb
loot give @s loot smoke:smoke_bomb
