# stuff commun

# particularité
give @s wooden_sword[unbreakable={}]