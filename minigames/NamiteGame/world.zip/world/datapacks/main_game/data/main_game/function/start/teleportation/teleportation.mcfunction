# teleporte toutes les personnes hide a un spawn random parmis ceux disponibles
execute as @a[team=hide] run tp @s @e[type=armor_stand,tag=hidespawn,sort=random,limit=1]
# teleporte tous les hunters a leurs points de spawns
execute as @a[team=hunter] run tp @s @e[type=armor_stand,tag=hunterspawn,sort=random,limit=1]