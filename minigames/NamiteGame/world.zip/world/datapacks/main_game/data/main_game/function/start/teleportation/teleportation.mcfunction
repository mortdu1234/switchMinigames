# teleporte toutes les personnes hide a un spawn random parmis ceux disponibles
execute as @a[team=hide] run tp @s @e[type=armor_stand,tag=hidespawn,sort=random,limit=1]
execute as @a[team=hide] run loot give @s loot smoke:smoke_bomb
execute as @a[team=hide] run loot give @s loot smoke:smoke_bomb

# teleporte tous les hunters a leurs points de spawns
execute as @a[team=hunter] run tp @s @e[type=armor_stand,tag=hunterspawn,sort=random,limit=1]
execute as @a[team=hunter] run give @s crossbow
execute as @a[team=hunter] run give @s spectral_arrow 2
execute as @a[team=hunter] run give @s arrow 6