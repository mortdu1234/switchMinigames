execute as @a run advancement revoke @a only teamloot:chest_open
tellraw @a [{"text":"[team loot table] ","color":"gray"},{"text":"datapack loaded","color":"green"}]
