# appel quand on ouvre un barrel
# On revoque l'advancement pour qu'elle puisse re-declencher sur le prochain coffre ouvert
advancement revoke @s only teamloot:chest_open

execute as @a at @s anchored eyes run function teamloot:detect
