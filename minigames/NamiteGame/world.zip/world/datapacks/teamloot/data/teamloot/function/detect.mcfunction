# Cherche, dans l'axe du regard du joueur (jusqu'a 6 blocs), un coffre marque "Coffre Mystere"
# Des qu'il en trouve un, il appelle teamloot:fill positionne exactement sur ce coffre.
execute positioned ^ ^ ^1 if block ~ ~ ~ minecraft:barrel{components:{"minecraft:custom_data":{"generate":0b}}} run function teamloot:fill
execute positioned ^ ^ ^2 if block ~ ~ ~ minecraft:barrel{components:{"minecraft:custom_data":{"generate":0b}}} run function teamloot:fill
execute positioned ^ ^ ^3 if block ~ ~ ~ minecraft:barrel{components:{"minecraft:custom_data":{"generate":0b}}} run function teamloot:fill
execute positioned ^ ^ ^4 if block ~ ~ ~ minecraft:barrel{components:{"minecraft:custom_data":{"generate":0b}}} run function teamloot:fill
execute positioned ^ ^ ^5 if block ~ ~ ~ minecraft:barrel{components:{"minecraft:custom_data":{"generate":0b}}} run function teamloot:fill
execute positioned ^ ^ ^6 if block ~ ~ ~ minecraft:barrel{components:{"minecraft:custom_data":{"generate":0b}}} run function teamloot:fill
