# Ce point est appelé positionne EXACTEMENT sur le bloc du coffre vise (~ ~ ~ = le coffre),
# et "as @s" = le joueur qui vient d'ouvrir le coffre.
#
# /!\ Adapte "Red" et "Blue" aux noms EXACTS de tes deux equipes (/team list)

# test pour les kits hide
execute as @s[team=hide, scores={main_game_class_hide_classic=1}] run loot insert ~ ~ ~ loot teamloot:chests/hide/classic
execute as @s[team=hide, scores={main_game_class_hide_invisible=1}] run loot insert ~ ~ ~ loot teamloot:chests/hide/invisible
execute as @s[team=hide, scores={main_game_class_hide_smoker=1}] run loot insert ~ ~ ~ loot teamloot:chests/hide/smoker


# test pour les kits hunter
execute as @s[team=hunter, scores={main_game_class_hunter_classic=1}] run loot insert ~ ~ ~ loot teamloot:chests/hunter/classic
execute as @s[team=hunter, scores={main_game_class_hunter_archer=1}] run loot insert ~ ~ ~ loot teamloot:chests/hunter/archer
execute as @s[team=hunter, scores={main_game_class_hunter_pyroman=1}] run loot insert ~ ~ ~ loot teamloot:chests/hunter/pyroman
execute as @s[team=hunter, scores={main_game_class_hunter_spearman=1}] run loot insert ~ ~ ~ loot teamloot:chests/hunter/spearman
execute as @s[team=hunter, scores={main_game_class_hunter_swordman=1}] run loot insert ~ ~ ~ loot teamloot:chests/hunter/swordman

# Si le joueur n'est dans aucune des deux equipes, rien n'est donne (a adapter si besoin :
# tu peux ajouter une loot_table "neutre" par defaut ici).

# On retire le marqueur : le coffre est maintenant fige, son contenu ne sera plus jamais
# regenere meme si quelqu'un d'autre l'ouvre ensuite (comportement "coffre normal").
data modify block ~ ~ ~ components.minecraft:custom_data.generate set value 1b
