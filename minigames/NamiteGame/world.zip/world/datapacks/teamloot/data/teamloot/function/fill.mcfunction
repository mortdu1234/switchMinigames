# Ce point est appelé positionne EXACTEMENT sur le bloc du coffre vise (~ ~ ~ = le coffre),
# et "as @s" = le joueur qui vient d'ouvrir le coffre.
#
# /!\ Adapte "Red" et "Blue" aux noms EXACTS de tes deux equipes (/team list)

execute if entity @s[team=hunter] run loot insert ~ ~ ~ loot teamloot:chests/hunter
execute if entity @s[team=hide] run loot insert ~ ~ ~ loot teamloot:chests/hide

# Si le joueur n'est dans aucune des deux equipes, rien n'est donne (a adapter si besoin :
# tu peux ajouter une loot_table "neutre" par defaut ici).

# On retire le marqueur : le coffre est maintenant fige, son contenu ne sera plus jamais
# regenere meme si quelqu'un d'autre l'ouvre ensuite (comportement "coffre normal").
data modify block ~ ~ ~ components.minecraft:custom_data.generate set value 1b
