# =========================================================
#   SMOKE BOMB - PARTICULES CONTINUES
# =========================================================
# Appelée chaque tick, tant que l'item "fumée" existe, pour
# faire un nuage continu (et pas juste un effet ponctuel).
# =========================================================

$particle minecraft:campfire_cosy_smoke ~ ~0.5 ~ $(spread) $(spread) $(spread) $(speed) $(count)
