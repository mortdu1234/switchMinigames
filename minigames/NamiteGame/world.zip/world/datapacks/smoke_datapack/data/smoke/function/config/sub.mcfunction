$execute if score $(key) smoke_cfg matches 1.. run scoreboard players remove $(key) smoke_cfg 1

$tellraw @p ["",{text:"value :"},{score:{name:"$(key)",objective:"smoke_cfg"}}]