# =========================================================
#   SMOKE BOMB - CONVERSION CONFIG -> STORAGE
# =========================================================
# Convertit les valeurs de l'objectif "smoke_cfg" en storage
# pour pouvoir les injecter dans des commandes via des macros.
# Appelée automatiquement par tick.mcfunction.
# =========================================================

execute store result storage smoke:config count int 1 run scoreboard players get particle_count smoke_cfg
execute store result storage smoke:config height int 1 run scoreboard players get height_offset smoke_cfg
execute store result storage smoke:config spread float 0.1 run scoreboard players get particle_spread smoke_cfg
execute store result storage smoke:config speed float 0.1 run scoreboard players get particle_speed smoke_cfg
execute store result storage smoke:config volume float 0.1 run scoreboard players get sound_volume smoke_cfg
execute store result storage smoke:config pitch float 0.1 run scoreboard players get sound_pitch smoke_cfg

scoreboard players set #temp smoke_cfg 6000
scoreboard players operation #temp smoke_cfg -= lifetime smoke_cfg
execute store result storage smoke:config item_age int 1 run scoreboard players get #temp smoke_cfg
