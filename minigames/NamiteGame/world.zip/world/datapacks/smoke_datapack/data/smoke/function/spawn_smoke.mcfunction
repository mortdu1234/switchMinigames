# =========================================================
#   SMOKE BOMB - SPAWN (déclenché une fois à l'impact)
# =========================================================
# Doit être appelée ainsi :
#   execute ... run function smoke:spawn_smoke with storage smoke:config
# =========================================================

$particle minecraft:campfire_cosy_smoke ~ ~$(height) ~ $(spread) $(spread) $(spread) $(speed) $(count)
$playsound minecraft:block.fire.extinguish ambient @a ~ ~ ~ $(volume) $(pitch)
$summon item ~ ~$(height) ~ {PickupDelay:32767,NoGravity:1b,Motion:[0.0,0.0,0.0],Age:$(item_age),Item:{id:"minecraft:gray_dye",count:1,components:{"minecraft:custom_data":{bomb:smoke}}}}
