# =========================================================
#   SMOKE BOMB - BOUCLE PRINCIPALE (appelée chaque tick)
# =========================================================

# --- Met à jour le storage de config (une fois par tick) ---
function smoke:update_config

# --- Détecte les items "fumée" (lancés par spawn_smoke, ou placés à la main) ---
execute as @e[type=item] unless score @s smoke_bomb = @s smoke_bomb if predicate {condition:"minecraft:entity_properties",entity:"this",predicate:{slots:{contents:{items:"minecraft:gray_dye",count:1,predicates:{"minecraft:custom_data":"{bomb:'smoke'}"}}}}} store success entity @s PickupDelay short 32767 store success score @s smoke_bomb at @s run playsound minecraft:block.fire.extinguish ambient @a ~ ~ ~ 1 0

# --- Émission continue de particules tant que l'item "fumée" existe ---
execute as @e[type=item,scores={smoke_bomb=1}] at @s run function smoke:tick_particle with storage smoke:config

# --- Détecte le lancer d'une boule de neige "fumée" par un joueur ---
execute as @a[scores={used_snowball=1..}] anchored eyes at @s positioned ^ ^ ^.5 at @n[type=minecraft:snowball, nbt={Item:{components:{"minecraft:custom_data":{smoke:true}}}}] run summon minecraft:snowball ~ ~ ~ {Tags:["init"], Passengers:[{id:"minecraft:area_effect_cloud",Duration:6000,Tags:["smoke_target"],NoGravity:1b,Motion:[0.0,0.0,0.0]}]}
scoreboard players reset @a used_snowball

# --- Transfère la vélocité de la vraie boule de neige vers la boule "porteuse" de l'effet ---
execute at @e[type=minecraft:snowball, tag=init] as @e[type=minecraft:snowball,tag=!init,distance=..0.1,limit=1] store success entity @s Pos[1] double -5000 run data modify entity @e[type=minecraft:snowball,tag=init,distance=..0.1,limit=1] Motion set from entity @s Motion
tag @e[type=minecraft:snowball,tag=init] remove init

# --- Détecte l'impact : la zone d'effet n'a plus de monture (la boule de neige a été détruite) ---
execute as @e[type=minecraft:area_effect_cloud,tag=smoke_target] at @s unless predicate {"condition":"minecraft:entity_properties","entity":"this","predicate":{"vehicle":{}}} run function smoke:spawn_smoke with storage smoke:config
execute as @e[type=minecraft:area_effect_cloud,tag=smoke_target] unless predicate {"condition":"minecraft:entity_properties","entity":"this","predicate":{"vehicle":{}}} run kill @s
