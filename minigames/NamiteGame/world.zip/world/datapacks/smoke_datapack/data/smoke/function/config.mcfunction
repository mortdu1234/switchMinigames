# =========================================================
#   SMOKE BOMB - CONFIGURATION
# =========================================================
# Relance cette fonction pour (re)initialiser la config :
#   /function smoke:config
#
# Puis modifie une valeur avec :
#   /scoreboard players set <clé> smoke_cfg <valeur>
#
# CLÉS DISPONIBLES :
#  particle_count   nombre de particules par effet       (def: 100)
#  particle_spread  dispersion, en dixièmes de bloc       (def: 10  -> 1.0 bloc)
#  particle_speed   vitesse des particules, en dixièmes   (def: 0   -> 0.0)
#  height_offset    hauteur d'apparition (en blocs)       (def: 2)
#  lifetime         durée de vie de la fumée, en ticks    (def: 100 -> 5 sec)
#  sound_volume     volume du son, en dixièmes            (def: 10  -> 1.0)
#  sound_pitch      pitch du son, en dixièmes             (def: 10  -> 1.0)
#
# EXEMPLES :
#  /scoreboard players set lifetime smoke_cfg 200        -> fumée qui dure 10 sec
#  /scoreboard players set particle_count smoke_cfg 300  -> fumée plus dense
#  /scoreboard players set height_offset smoke_cfg 0     -> fumée qui apparait au sol
#  /scoreboard players set particle_spread smoke_cfg 20  -> nuage 2x plus large
# =========================================================

scoreboard objectives add smoke_cfg dummy

scoreboard players set particle_count smoke_cfg 500
scoreboard players set particle_spread smoke_cfg 15
scoreboard players set particle_speed smoke_cfg 0
scoreboard players set height_offset smoke_cfg 1
scoreboard players set lifetime smoke_cfg 200
scoreboard players set sound_volume smoke_cfg 10
scoreboard players set sound_pitch smoke_cfg 10

tellraw @a [{"text":"[Smoke Bomb] ","color":"gray"},{"text":"Configuration réinitialisée aux valeurs par défaut.","color":"green"}]
