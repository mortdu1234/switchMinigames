# Lancé une fois au chargement du datapack / du monde.

# Objectif qui détecte automatiquement quand un joueur lance une boule de neige
scoreboard objectives add used_snowball minecraft.used:minecraft.snowball

# Objectif qui marque les items "fumée" déjà détectés
scoreboard objectives add smoke_bomb dummy

function smoke:config
