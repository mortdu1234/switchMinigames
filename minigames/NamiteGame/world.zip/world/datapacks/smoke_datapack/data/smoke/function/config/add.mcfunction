$scoreboard players add $(key) smoke_cfg 1

$tellraw @p ["",{text:"value :"},{score:{name:"$(key)",objective:"smoke_cfg"}}]