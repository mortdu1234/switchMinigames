execute if score #G_TIMER GlowingTimer matches 4800.. run scoreboard players remove #G_TIMER GlowingTimer 4800
execute if score #G_TIMER_SET GlowingTimer matches 4800.. run scoreboard players remove #G_TIMER_SET GlowingTimer 4800
execute if score #G_TIMER_M GlowingTimerM matches 4.. run scoreboard players remove #G_TIMER_M GlowingTimerM 4

execute if score #G_TIMER GlowingTimer matches 0 run title @a actionbar ["",{"text":"Glowing","color":"gold"}," has been ",{"text":"disabled","color":"gray"}]
execute if score #G_TIMER GlowingTimer matches 1.. run title @a actionbar ["","Players will start",{"text":" Glowing ","color":"gold"},"after ",{"score":{"name":"#G_TIMER_M","objective":"GlowingTimerM"},"color":"gold"}," minutes"]

# ACTIVATE GLOWING AT #G_TIMER GlowingTimer matches 1 !!!