setblock 1086 22 1058 lever[facing=east,powered=false]
setblock 1086 19 1058 lever[facing=east,powered=false]
#
setblock 1084 22 1058 redstone_lamp[lit=false]
setblock 1084 19 1058 redstone_lamp[lit=false]
#
fill 1065 19 1067 1065 19 1068 minecraft:purple_concrete