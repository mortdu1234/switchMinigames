execute if score #C_TIMER CombatTimer matches ..23999 run scoreboard players add #C_TIMER CombatTimer 2400
execute if score #C_TIMER_SET CombatTimer matches ..23999 run scoreboard players add #C_TIMER_SET CombatTimer 2400
execute if score #C_TIMER_M CombatTimerM matches ..19 run scoreboard players add #C_TIMER_M CombatTimerM 2
execute if score #C_TIMER_M CombatTimerM matches 1.. run title @a actionbar ["",{"text":"PvP","color":"gold"}," will be disabled the first ",{"score":{"name":"#C_TIMER_M","objective":"CombatTimerM"},"color":"gold"}," minutes"]


# ACTIVATE GLOWING AT #C_TIMER CombatTimer matches 1 !!!
# 2 minutes