execute if score #C_TIMER CombatTimer matches 2400.. run scoreboard players remove #C_TIMER CombatTimer 2400
execute if score #C_TIMER_SET CombatTimer matches 2400.. run scoreboard players remove #C_TIMER_SET CombatTimer 2400

execute if score #C_TIMER_M CombatTimerM matches 2.. run scoreboard players remove #C_TIMER_M CombatTimerM 2

execute if score #C_TIMER_M CombatTimerM matches 0 run title @a actionbar ["",{"text":"Combat Timer","color":"gold"}," has been ",{"text":"disabled","color":"gray"}]
execute if score #C_TIMER_M CombatTimerM matches 1.. run title @a actionbar ["",{"text":"Combat","color":"gold"}," will be disabled the first ",{"score":{"name":"#C_TIMER_M","objective":"CombatTimerM"},"color":"gold"}," minutes"]

# ACTIVATE GLOWING AT #C_TIMER CombatTimer matches 1 !!!
# 2 minutes