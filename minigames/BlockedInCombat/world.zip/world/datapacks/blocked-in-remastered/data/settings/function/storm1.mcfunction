worldborder set 40 0
schedule function settings:storm2 5
title @a title {"text":"⛈ The storm is closing in! ⛈","italic":true,"color":"dark_aqua"}