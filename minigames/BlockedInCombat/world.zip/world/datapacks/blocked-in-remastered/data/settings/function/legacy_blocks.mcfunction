fill 1086 22 1057 1086 22 1044 lever[facing=east,powered=true]
fill 1084 22 1057 1084 22 1044 redstone_lamp[lit=true]
#
fill 1086 19 1057 1086 19 1048 lever[facing=east,powered=true]
fill 1084 19 1057 1084 19 1048 redstone_lamp[lit=true]
#
fill 1065 19 1062 1065 19 1039 minecraft:purple_concrete
#Off
setblock 1086 22 1058 lever[facing=east,powered=false]
setblock 1086 19 1058 lever[facing=east,powered=false]
fill 1086 19 1047 1086 19 1044 lever[facing=east,powered=false]
#
setblock 1084 22 1058 redstone_lamp[lit=false]
setblock 1084 19 1058 redstone_lamp[lit=false]
fill 1084 19 1047 1084 19 1044 redstone_lamp[lit=false]