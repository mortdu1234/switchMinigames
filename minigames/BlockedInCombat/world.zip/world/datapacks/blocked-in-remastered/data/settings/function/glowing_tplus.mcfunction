execute if score #G_TIMER GlowingTimer matches ..35999 run scoreboard players add #G_TIMER GlowingTimer 4800
execute if score #G_TIMER_SET GlowingTimer matches ..35999 run scoreboard players add #G_TIMER_SET GlowingTimer 4800
execute if score #G_TIMER_M GlowingTimerM matches ..39 run scoreboard players add #G_TIMER_M GlowingTimerM 4
execute if score #G_TIMER GlowingTimer matches 1.. run title @a actionbar ["","Players will start",{"text":" Glowing ","color":"gold"},"after ",{"score":{"name":"#G_TIMER_M","objective":"GlowingTimerM"},"color":"gold"}," minutes"]


# ACTIVATE GLOWING AT #G_TIMER GlowingTimer matches 1 !!!