execute if score #MINIGAMERUNNING MinigameRunning matches 1 run execute if score #Lava_Y FloorLavaY matches 10 run fill 1017 10 1038 1047 10 1068 lava
execute if score #MINIGAMERUNNING MinigameRunning matches 1 run execute if score #Lava_Y FLoorLavaY matches 10 run title @a title ["",{"text":"The","bold":true,"color":"gold"},{"text":" lava ","bold":true,"color":"dark_red"},{"text":"is rising","bold":true,"color":"gold"}]
execute if score #MINIGAMERUNNING MinigameRunning matches 1 run execute if score #Lava_Y FloorLavaY matches 11 run fill 1017 10 1038 1047 11 1068 lava
execute if score #MINIGAMERUNNING MinigameRunning matches 1 run execute if score #Lava_Y FloorLavaY matches 12 run fill 1017 10 1038 1047 12 1068 lava
execute if score #MINIGAMERUNNING MinigameRunning matches 1 run execute if score #Lava_Y FloorLavaY matches 13 run fill 1017 10 1038 1047 13 1068 lava
execute if score #MINIGAMERUNNING MinigameRunning matches 1 run execute if score #Lava_Y FloorLavaY matches 14 run fill 1017 10 1038 1047 14 1068 lava
execute if score #MINIGAMERUNNING MinigameRunning matches 1 run execute if score #Lava_Y FloorLavaY matches 15 run fill 1017 10 1038 1047 15 1068 lava
execute if score #MINIGAMERUNNING MinigameRunning matches 1 run execute if score #Lava_Y FloorLavaY matches 16 run fill 1017 10 1038 1047 16 1068 lava
execute if score #MINIGAMERUNNING MinigameRunning matches 1 run execute if score #Lava_Y FloorLavaY matches 17 run fill 1017 10 1038 1047 17 1068 lava
scoreboard players add #Lava_Y FloorLavaY 1
execute if score #MINIGAMERUNNING MinigameRunning matches 1 run schedule function settings:floor_lava 1