fill 1086 22 1044 1086 22 1058 lever[facing=east,powered=true]
fill 1084 22 1044 1084 22 1058 redstone_lamp[lit=true]
#
fill 1086 19 1044 1086 19 1058 lever[facing=east,powered=true]
fill 1084 19 1044 1084 19 1058 redstone_lamp[lit=true]
#
fill 1065 19 1068 1065 19 1039 minecraft:purple_concrete