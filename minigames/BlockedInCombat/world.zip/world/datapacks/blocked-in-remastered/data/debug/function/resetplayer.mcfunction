scoreboard players set @s dead 0
gamemode adventure @s
team leave @s
function debug:lobby
effect give @s regeneration 1 255 true
effect give @s saturation 1 255 true
clear @s