setblock 1069 19 1061 air
title @a title ["","The ",{"text":"Yellow ","bold":true,"color":"yellow"},"team won!"]
function blockedin:reset