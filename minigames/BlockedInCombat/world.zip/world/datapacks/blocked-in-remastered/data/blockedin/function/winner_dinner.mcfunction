execute as @a[scores={dead=1..}] run team join Spectator @a[scores={dead=1..}]
gamemode spectator @a[team=Spectator,scores={dead=1..}]
execute if entity @a[team=Green] unless entity @a[team=!Green,team=!Spectator] run function blockedin:green
execute if entity @a[team=Blue] unless entity @a[team=!Blue,team=!Spectator] run function blockedin:blue
execute if entity @a[team=Orange] unless entity @a[team=!Orange,team=!Spectator] run function blockedin:orange
execute if entity @a[team=Yellow] unless entity @a[team=!Yellow,team=!Spectator] run function blockedin:yellow

# Mini-games
execute if score #MINIGAMERUNNING MinigameRunning matches 1 run execute if score #G_TIMER GlowingTimer matches 1.. run scoreboard players remove #G_TIMER GlowingTimer 1
execute if score #G_TIMER GlowingTimer matches 1 run effect give @a minecraft:glowing infinite 255 true

execute if score #FLOORLAVAONOFF FloorLavaY matches 1 run execute if score #Lava_Timer FloorLavaTimer matches 1.. run scoreboard players remove #Lava_Timer FloorLavaTimer 1
execute if score #FLOORLAVAONOFF FloorLavaY matches 1 run execute if score #Lava_Timer FloorLavaTimer matches 60 run playsound block.note_block.pling master @a ~ ~ ~ 999999
execute if score #FLOORLAVAONOFF FloorLavaY matches 1 run execute if score #Lava_Timer FloorLavaTimer matches 40 run playsound block.note_block.pling master @a ~ ~ ~ 999999
execute if score #FLOORLAVAONOFF FloorLavaY matches 1 run execute if score #Lava_Timer FloorLavaTimer matches 20 run playsound block.note_block.pling master @a ~ ~ ~ 999999
execute if score #FLOORLAVAONOFF FloorLavaY matches 1 run execute if score #Lava_Timer FloorLavaTimer matches 1 run playsound block.note_block.pling master @a ~ ~ ~ 999999 2
execute if score #FLOORLAVAONOFF FloorLavaY matches 1 run execute if score #Lava_Timer FloorLavaTimer matches 60 run title @a actionbar {"text":"The lava is about to rise!","bold":true,"color":"gold"}


execute if score #MINIGAMERUNNING MinigameRunning matches 1.. run execute if score #C_TIMER CombatTimer matches 1.. run effect give @a weakness 1 255 true
execute if score #MINIGAMERUNNING MinigameRunning matches 1 run execute if score #C_TIMER CombatTimer matches 1.. run scoreboard players remove #C_TIMER CombatTimer 1
execute if score #C_TIMER CombatTimer matches 2 run playsound entity.wither.spawn master @a ~ ~ ~ 9999
execute if score #C_TIMER CombatTimer matches 1 run title @a title ["",{"text":"⚠","obfuscated":true,"color":"gold"},{"text":" PVP","bold":true,"color":"red"},{"text":" IS NOW ENABLED ","bold":true,"color":"red"},{"text":"⚠","bold":true,"obfuscated":true,"color":"gold"}]