fill 1016 21 1069 1048 21 1037 air
fill 1047 20 1038 1017 10 1068 air
team join Spectator @a[team=]
scoreboard players set #MINIGAME MinigameStatus 1
spawnpoint @a 1032 22 1053

# Check if there are players in the teams
execute if entity @a[team=Blue] run summon armor_stand 1032 64 1053 {Invisible:1b,Marker:1b,Tags:["BlueTeamSpawn","SpawnDummy"]}
execute if entity @a[team=Green] run summon armor_stand 1032 64 1053 {Invisible:1b,Marker:1b,Tags:["GreenTeamSpawn","SpawnDummy"]}
execute if entity @a[team=Yellow] run summon armor_stand 1032 64 1053 {Invisible:1b,Marker:1b,Tags:["YellowTeamSpawn","SpawnDummy"]}
execute if entity @a[team=Orange] run summon armor_stand 1032 64 1053 {Invisible:1b,Marker:1b,Tags:["OrangeTeamSpawn","SpawnDummy"]}
spreadplayers 1032 1053 8 14 false @e[tag=SpawnDummy]
# schedule function blockedin:spread_teams 20