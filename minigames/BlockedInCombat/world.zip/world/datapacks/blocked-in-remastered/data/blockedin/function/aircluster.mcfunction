fill 1048 21 1037 1016 21 1069 bedrock

execute if entity @a[team=Blue] run execute at @e[tag=BlueTeamSpawn,limit=1] run fill ~ 14 ~ ~1 13 ~1 air
execute if entity @a[team=Green] run execute at @e[tag=GreenTeamSpawn,limit=1] run fill ~ 14 ~ ~1 13 ~1 air
execute if entity @a[team=Yellow] run execute at @e[tag=YellowTeamSpawn,limit=1] run fill ~ 14 ~ ~1 13 ~1 air
execute if entity @a[team=Orange] run execute at @e[tag=OrangeTeamSpawn,limit=1] run fill ~ 14 ~ ~1 13 ~1 air

schedule function blockedin:teleport 5

execute if block 1091 19 1053 redstone_lamp[lit=true] run setblock 1056 19 1031 redstone_block
schedule function blockedin:bonus_chest 5
gamemode survival @a[team=!Spectator]
setblock 1070 19 1057 redstone_block
setblock 1069 19 1061 redstone_block