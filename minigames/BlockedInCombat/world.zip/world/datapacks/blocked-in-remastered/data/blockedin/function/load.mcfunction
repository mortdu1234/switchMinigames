scoreboard players set #MINIGAME MinigameStatus 0
scoreboard players set #MINIGAMERUNNING MinigameRunning 0
scoreboard players set #String StartingSequence 0
scoreboard players set #TeamCheck StartingSequence 0

gamerule allow_entering_nether_using_portals false
gamerule command_blocks_work true

function blockedin:reset