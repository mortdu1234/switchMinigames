tp @a 1126.5 21 1043.5 0 0
spawnpoint @a 1126 21 1043