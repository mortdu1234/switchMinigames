setblock 1070 19 1048 minecraft:redstone_block
setblock 1070 19 1052 minecraft:redstone_block
setblock 1070 19 1032 minecraft:redstone_block
setblock 1070 19 1050 minecraft:redstone_block
setblock 1048 22 1038 barrier
execute if block 1092 20 1069 minecraft:repeater[powered=true] run schedule function settings:storm1 400