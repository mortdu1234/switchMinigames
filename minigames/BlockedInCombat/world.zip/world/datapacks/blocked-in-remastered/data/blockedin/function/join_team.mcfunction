execute if score #String StartingSequence matches 0 run execute as @a[x=1156.5,y=25,z=1053.5,dx=1.5,dy=0,dz=1.5,team=!Orange] run tellraw @a ["",{"selector":"@s","bold":true,"color":"gold"},{"text":" has joined the Orange team!","color":"gold"}]
execute if score #String StartingSequence matches 0 run playsound block.note_block.pling master @a[x=1156.5,y=25,z=1053.5,dx=1.5,dy=0,dz=1.5,team=!Orange] ~ ~ ~ 999999
execute if score #String StartingSequence matches 0 run execute as @a[x=1156.5,y=25,z=1053.5,dx=1.5,dy=0,dz=1.5,team=!Orange] run team join Orange @a[x=1156.5,y=25,z=1053.5,dx=1.5,dy=0,dz=1.5]

execute if score #String StartingSequence matches 0 run execute as @a[x=1156.5,y=25,z=1057.5,dx=1.5,dy=0,dz=1.5,team=!Blue] run tellraw @a ["",{"selector":"@s","bold":true,"color":"aqua"},{"text":" has joined the Blue team!","color":"aqua"}]
execute if score #String StartingSequence matches 0 run playsound block.note_block.pling master @a[x=1156.5,y=25,z=1057.5,dx=1.5,dy=0,dz=1.5,team=!Blue] ~ ~ ~ 999999
execute if score #String StartingSequence matches 0 run execute as @a[x=1156.5,y=25,z=1057.5,dx=1.5,dy=0,dz=1.5,team=!Blue] run team join Blue @a[x=1156.5,y=25,z=1057.5,dx=1.5,dy=0,dz=1.5]

execute if score #String StartingSequence matches 0 run execute as @a[x=1157.5,y=25,z=1049.5,dx=1.5,dy=0,dz=1.5,team=!Yellow] run tellraw @a ["",{"selector":"@s","bold":true,"color":"yellow"},{"text":" has joined the Yellow team!","color":"yellow"}]
execute if score #String StartingSequence matches 0 run playsound block.note_block.pling master @a[x=1157.5,y=25,z=1049.5,dx=1.5,dy=0,dz=1.5,team=!Yellow] ~ ~ ~ 999999
execute if score #String StartingSequence matches 0 run execute as @a[x=1157.5,y=25,z=1049.5,dx=1.5,dy=0,dz=1.5,team=!Yellow] run team join Yellow @a[x=1157.5,y=25,z=1049.5,dx=1.5,dy=0,dz=1.5]

execute if score #String StartingSequence matches 0 run execute as @a[x=1157.5,y=25,z=1061.5,dx=1.5,dy=0,dz=1.5,team=!Green] run tellraw @a ["",{"selector":"@s","bold":true,"color":"green"},{"text":" has joined the Green team!","color":"green"}]
execute if score #String StartingSequence matches 0 run playsound block.note_block.pling master @a[x=1157.5,y=25,z=1061.5,dx=1.5,dy=0,dz=1.5,team=!Green] ~ ~ ~ 999999
execute if score #String StartingSequence matches 0 run execute as @a[x=1157.5,y=25,z=1061.5,dx=1.5,dy=0,dz=1.5,team=!Green] run team join Green @a[x=1157.5,y=25,z=1061.5,dx=1.5,dy=0,dz=1.5]

execute if score #String StartingSequence matches 0 run execute as @a[x=1163.5,y=25,z=1060.5,dx=1.5,dy=0,dz=1.5,team=!Spectator] run tellraw @a ["",{"selector":"@s","bold":true,"color":"gray"},{"text":" will be a spectator next round!","color":"gray"}]
execute if score #String StartingSequence matches 0 run playsound block.note_block.pling master @a[x=1163.5,y=25,z=1060.5,dx=1.5,dy=0,dz=1.5,team=!Spectator] ~ ~ ~ 999999
execute if score #String StartingSequence matches 0 run execute as @a[x=1163.5,y=25,z=1060.5,dx=1.5,dy=0,dz=1.5] run team join Spectator @a[x=1163.5,y=25,z=1060.5,dx=1.5,dy=0,dz=1.5]