effect give @a night_vision infinite 0 true
execute if score #MINIGAME MinigameStatus matches 0 run effect give @a saturation 3 255 true
execute if score #MINIGAMERUNNING MinigameRunning matches 0 run effect give @a resistance 3 255 true
execute if score #MINIGAMERUNNING MinigameRunning matches 0 run effect give @a weakness 3 255 true
execute if score #MINIGAME MinigameStatus matches 0 run effect give @a regeneration 3 255 true
execute if score #MINIGAME MinigameStatus matches 1 run execute as @a[team=] run team join Spectator @a[team=]
execute if score #MINIGAMERUNNING MinigameRunning matches 1 run gamemode spectator @a[team=Spectator]
function blockedin:first_login
function blockedin:spectator_shield
clear @a[team=Spectator,scores={dead=1..}]
execute if entity @a[team=Spectator,scores={dead=1..}] run execute as @s[team=Spectator,scores={dead=1..}] if block ~ ~0.1 ~ black_concrete run tp @s 1032.5 40 1053.5 90 90
fill 1049 8 1070 1015 22 1036 air replace nether_portal

execute as @a[x=1117,y=20,z=1050,distance=..1] run effect give @s minecraft:levitation 2 3 true
execute as @a[x=1121,y=23,z=1048,distance=..1] run effect give @s minecraft:slow_falling 1 2 true
execute as @a[x=1125,y=27,z=1050,distance=..1] run effect give @s minecraft:slow_falling 2 2 true
