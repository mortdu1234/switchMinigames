# Roof
execute as @a[team=Spectator,scores={dead=1..},x=1015,y=62,z=1036,dx=34,dy=-5,dz=34] run tp @s 1032.5 40 1053.5

#Floor
execute as @a[team=Spectator,scores={dead=1..},x=1015,y=8,z=1036,dx=34,dy=0,dz=34] run tp @s 1032.5 40 1053.5

#Walls
#east
execute as @a[team=Spectator,scores={dead=1..},x=1049,y=9,z=1036,dx=5,dy=52,dz=34] run tp @s 1032.5 40 1053.5
#west
execute as @a[team=Spectator,scores={dead=1..},x=1015,y=9,z=1036,dx=-5,dy=52,dz=34] run tp @s 1032.5 40 1053.5
#south
execute as @a[team=Spectator,scores={dead=1..},x=1015,y=9,z=1070,dx=34,dy=52,dz=5] run tp @s 1032.5 40 1053.5
#north
execute as @a[team=Spectator,scores={dead=1..},x=1015,y=9,z=1036,dx=34,dy=52,dz=-5] run tp @s 1032.5 40 1053.5