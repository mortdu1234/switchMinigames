execute as @a[x=1126,y=30,z=1042,dx=2,dy=0,dz=2] run teleport @s 1126.5 21 1043.5 0 0
execute as @a[x=1126,y=21,z=1042,dx=2,dy=0,dz=2] run gamemode adventure @s
effect clear