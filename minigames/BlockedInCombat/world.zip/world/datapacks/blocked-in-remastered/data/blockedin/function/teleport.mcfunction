execute if entity @a[team=Blue] run execute at @e[tag=BlueTeamSpawn,limit=1] run tp @a[team=Blue] ~ 13 ~
execute if entity @a[team=Green] run execute at @e[tag=GreenTeamSpawn,limit=1] run tp @a[team=Green] ~ 13 ~
execute if entity @a[team=Yellow] run execute at @e[tag=YellowTeamSpawn,limit=1] run tp @a[team=Yellow] ~ 13 ~
execute if entity @a[team=Orange] run execute at @e[tag=OrangeTeamSpawn,limit=1] run tp @a[team=Orange] ~ 13 ~