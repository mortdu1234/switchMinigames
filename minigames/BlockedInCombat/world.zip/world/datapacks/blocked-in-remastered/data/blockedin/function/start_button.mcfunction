scoreboard players set @a dead 0

scoreboard players set #TeamCheck StartingSequence 0
execute if entity @a[team=Orange] run scoreboard players add #TeamCheck StartingSequence 1
execute if entity @a[team=Yellow] run scoreboard players add #TeamCheck StartingSequence 1
execute if entity @a[team=Blue] run scoreboard players add #TeamCheck StartingSequence 1
execute if entity @a[team=Green] run scoreboard players add #TeamCheck StartingSequence 1

execute if score #TeamCheck StartingSequence matches ..1 run title @a actionbar {"text":"You need a player on at least two different teams to start the game!","bold":true,"color":"red"}
execute if score #TeamCheck StartingSequence matches ..1 run setblock 1165 41 1036 redstone_block
execute if score #TeamCheck StartingSequence matches ..1 run setblock 1165 41 1036 air

execute if score #TeamCheck StartingSequence matches 2.. run setblock 1070 19 1024 minecraft:redstone_block
execute if score #TeamCheck StartingSequence matches 2.. run setblock 1070 19 1024 air
execute if score #TeamCheck StartingSequence matches 2.. run scoreboard players set #String StartingSequence 1