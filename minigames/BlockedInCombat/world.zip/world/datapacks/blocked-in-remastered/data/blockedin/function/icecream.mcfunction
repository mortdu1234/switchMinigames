kill @e[name=Block]
kill @e[tag=block]
team join Spectator @a[team=]
setblock 1070 19 1048 minecraft:air
setblock 1070 19 1050 minecraft:air
setblock 1070 19 1045 minecraft:air
setblock 1070 19 1052 minecraft:air
setblock 1070 19 1032 minecraft:air
scoreboard players set arena_completion_timer arena_completion_timer 0
scoreboard players set #MINIGAMERUNNING MinigameRunning 1

function blockedin:aircluster
