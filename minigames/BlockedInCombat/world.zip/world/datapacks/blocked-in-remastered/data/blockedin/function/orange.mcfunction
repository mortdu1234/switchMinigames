setblock 1069 19 1061 air
title @a title ["","The ",{"text":"Orange ","bold":true,"color":"gold"},"team won!"]
function blockedin:reset