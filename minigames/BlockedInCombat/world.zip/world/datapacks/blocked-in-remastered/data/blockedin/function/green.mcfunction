setblock 1069 19 1061 air
title @a title ["","The ",{"text":"Green ","bold":true,"color":"green"},"team won!"]
function blockedin:reset