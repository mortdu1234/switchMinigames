# Teleports player back to lobby
tp @s 1126.5 21 1042.5 0 0
playsound entity.enderman.teleport master @a 1126.5 21 1042.5
tellraw @a ["",{"selector":"@s", "italic":true},{"text":" went back to the lobby!","italic":true}]