execute at @e[name=Block] run clone 1075 18 1024 1075 18 1054 ~ ~ ~
execute at @e[name=Block] run tp @e[name=Block] ~1 ~ ~
execute as @e[name=Block] at @s if block ~0.1 ~2 ~ minecraft:barrier run kill @s
execute as @e[name=Block] at @s if block ~0.1 ~ ~ minecraft:bedrock run tp @s 1017.5 ~1 ~