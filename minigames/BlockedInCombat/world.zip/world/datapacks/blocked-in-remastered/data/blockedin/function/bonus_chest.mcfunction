setblock 1056 19 1031 air
kill @e[type=item]