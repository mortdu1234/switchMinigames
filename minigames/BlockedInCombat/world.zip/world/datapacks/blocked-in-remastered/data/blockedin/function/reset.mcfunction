scoreboard players set @a dead 0
scoreboard players set #MINIGAME MinigameStatus 0
scoreboard players set #MINIGAMERUNNING MinigameRunning 0
scoreboard players set #String StartingSequence 0
scoreboard players set #TeamCheck StartingSequence 0

scoreboard players operation #C_TIMER CombatTimer = #C_TIMER_SET CombatTimer
scoreboard players operation #G_TIMER GlowingTimer = #G_TIMER_SET GlowingTimer

gamerule locator_bar false
gamerule minecraft:allow_entering_nether_using_portals false

gamemode adventure @a
xp set @a 0 points
xp set @a 0 levels
team leave @a
kill @e[type=item]
kill @e[tag=BlueTeamSpawn]
kill @e[tag=GreenTeamSpawn]
kill @e[tag=OrangeTeamSpawn]
kill @e[tag=YellowTeamSpawn]
clear @a
item replace entity @a enderchest.0 with air
item replace entity @a enderchest.1 with air
item replace entity @a enderchest.2 with air
item replace entity @a enderchest.3 with air
item replace entity @a enderchest.4 with air
item replace entity @a enderchest.5 with air
item replace entity @a enderchest.6 with air
item replace entity @a enderchest.7 with air
item replace entity @a enderchest.8 with air
item replace entity @a enderchest.9 with air
item replace entity @a enderchest.10 with air
item replace entity @a enderchest.11 with air
item replace entity @a enderchest.12 with air
item replace entity @a enderchest.13 with air
item replace entity @a enderchest.14 with air
item replace entity @a enderchest.15 with air
item replace entity @a enderchest.16 with air
item replace entity @a enderchest.17 with air
item replace entity @a enderchest.18 with air
item replace entity @a enderchest.19 with air
item replace entity @a enderchest.20 with air
item replace entity @a enderchest.21 with air
item replace entity @a enderchest.22 with air
item replace entity @a enderchest.23 with air
item replace entity @a enderchest.24 with air
item replace entity @a enderchest.25 with air
item replace entity @a enderchest.26 with air
schedule function blockedin:tpback 3
setblock 1165 26 1056 jungle_button[facing=west]
effect clear @a
worldborder set 59999968 0