setblock 1069 19 1061 air
title @a title ["","The ",{"text":"Blue ","bold":true,"color":"aqua"},"team won!"]
function blockedin:reset