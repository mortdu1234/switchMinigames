summon armor_stand 1017.5 10 1038.5 {CustomNameVisible:0b,NoGravity:1b,Marker:1b,Invisible:1b,CustomName:"Block"}
kill @e[type=item]

#floorLava
# execute if block 1092 20 1067 minecraft:repeater[powered=true] run schedule function settings:floor_lava 360
execute if score #FLOORLAVAONOFF FloorLavaY matches 1 run schedule function settings:floor_lava 360
scoreboard players set #Lava_Y FloorLavaY 10